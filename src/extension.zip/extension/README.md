# LinkedIn Job Bot

A Chrome Manifest V3 extension that scans LinkedIn for hiring posts, injects a floating sidebar, and attempts to auto-apply via Easy Apply or create Gmail drafts as fallback outreach.

## Extension structure

- `manifest.json` — Chrome extension manifest
- `background/service_worker.js` — alarms, badge updates, message handling
- `content/feed_scraper.js` — scans LinkedIn feed and content search pages
- `content/easy_apply.js` — auto-fills Easy Apply forms
- `content/sidebar.js` — floating sidebar interface
- `content/linkedin.js` — page lifecycle helpers and pending apply handling
- `popup/` — extension popup UI
- `options/` — settings page UI
- `utils/` — storage, Gmail draft creation, and template helpers
- `styles/sidebar.css` — sidebar styles
- `history.html` — application history viewer
- `icons/` — toolbar icons

## Developer setup

1. Open Google Cloud Console.
2. Create a new project or select an existing project.
3. Enable the Gmail API for that project.
4. Configure the OAuth consent screen (internal or external depending on your users).
5. Create OAuth credentials:
   - Choose `OAuth client ID`.
   - Select application type `Chrome App`.
   - Provide the extension's Chrome App ID if prompted.
6. Copy the generated `client_id` into `manifest.json` under `oauth2.client_id`.
7. Ensure the manifest scope includes:
   - `https://www.googleapis.com/auth/gmail.send`

> Developer note: end users do not need to create their own Google Cloud project. They only need to sign in to Chrome and approve the extension when prompted.

## Load as an unpublished extension (developer testing)

1. Open `chrome://extensions/`.
2. Enable `Developer mode`.
3. Click `Load unpacked`.
4. Select the `extension/` folder.

## Publish to Chrome Web Store

1. Zip the `extension/` folder contents.
2. Open the Chrome Web Store Developer Dashboard.
3. Create a new item and upload the zip file.
4. Provide store listing details, description, icons, and screenshots.
5. Add a privacy policy if required.
6. Submit the extension for review.

## End user setup

1. Install the extension from the Chrome Web Store.
2. Sign in to Chrome with a Google account.
3. When the extension requests Gmail access, approve the Chrome consent prompt.

> The extension uses `chrome.identity.getAuthToken()`, so it uses the user's already-signed-in Google account and does not require each user to configure their own OAuth project.

## How to use

1. Open LinkedIn.
2. Click the extension toolbar icon.
3. Click `Scan Now`.
4. Configure your profile and preferences in `Settings`.
5. Enable `Auto-apply` to allow automated Easy Apply behavior.
6. Enable `Email fallback` to create Gmail drafts when Easy Apply is unavailable.
7. Open `View History` to review application and draft activity.

## Data storage

- `chrome.storage.sync`: profile, preferences, templates, stats
- `chrome.storage.local`: seen posts, emailed recruiters, application history

## Notes

- The extension injects only the sidebar UI and avoids modifying LinkedIn native controls.
- Rate limiting is applied via delays between actions.
- If Easy Apply form structure is unexpected, the extension creates a Gmail draft as fallback outreach.
- Users must be signed into Chrome and approve Gmail access once.

importScripts("../utils/storage.js", "../utils/templates.js", "../utils/email.js");

console.log("[LJB] background service worker loaded");

function buildSearchUrl(keyword, dateFilter) {
  return (
    `https://www.linkedin.com/search/results/content/?` +
    `keywords=${encodeURIComponent(keyword)}` +
    `&datePosted=%5B%22${encodeURIComponent(dateFilter)}%22%5D` +
    `&origin=SWITCH_SEARCH_VERTICAL&sortBy=date_posted`
  );
}

function searchUrlsMatch(urlA, urlB) {
  try {
    const a = new URL(urlA);
    const b = new URL(urlB);
    if (a.pathname !== b.pathname) return false;
    return (
      a.searchParams.get("keywords") === b.searchParams.get("keywords") &&
      a.searchParams.get("datePosted") === b.searchParams.get("datePosted") &&
      a.searchParams.get("sortBy") === b.searchParams.get("sortBy")
    );
  } catch (error) {
    return false;
  }
}

const autoScanQueuedTabIds = new Set();

async function createAutoScanAlarm() {
  const settings = await LJBStorage.getSettings();
  const preferences = settings.preferences || {};
  const autoScanEnabled = preferences.autoScanEnabled !== false;
  if (!autoScanEnabled) {
    chrome.alarms.clear("auto-scan");
    return;
  }
  const interval = Math.max(1, Math.min(1440, Number(preferences.runInterval || 30)));
  chrome.alarms.clear("auto-scan", () => {
    chrome.alarms.create("auto-scan", { periodInMinutes: interval });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  createAutoScanAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  createAutoScanAlarm();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && changes.preferences) {
    createAutoScanAlarm();
  }
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  console.log("[LJB] alarm fired", alarm);
  if (alarm.name !== "auto-scan") {
    return;
  }

  const settings = await LJBStorage.getSettings();
  const preferences = settings.preferences || {};
  const autoScanEnabled = preferences.autoScanEnabled !== false;
  if (!autoScanEnabled) {
    console.log("[LJB] Auto-scan disabled, skipping alarm.");
    return;
  }

  const keywords = Array.isArray(preferences.keywords) ? preferences.keywords : [];
  const dateFilter = preferences.dateFilter || "past-24h";
  const searchUrls = keywords.filter(Boolean).map((keyword) => buildSearchUrl(keyword, dateFilter));

  if (searchUrls.length === 0) {
    console.log("[LJB] No keywords configured for auto-scan.");
    return;
  }

  chrome.tabs.query({ url: ["https://www.linkedin.com/search/results/content/*", "https://linkedin.com/search/results/content/*"] }, (tabs) => {
    console.log("[LJB] search tabs found", tabs?.length);
    searchUrls.forEach((url) => {
      const matchingTab = (tabs || []).find((tab) => tab.url && searchUrlsMatch(tab.url, url));
      if (matchingTab) {
        console.log("[LJB] updating existing search tab", matchingTab.id, url);
        chrome.tabs.update(matchingTab.id, { url });
        autoScanQueuedTabIds.add(matchingTab.id);
        chrome.tabs.sendMessage(matchingTab.id, { type: "AUTO_SCAN_PAGE" }, () => {
          if (chrome.runtime.lastError) {
            console.warn("[LJB] AUTO_SCAN_PAGE message not ready:", chrome.runtime.lastError.message);
          } else {
            console.log("[LJB] AUTO_SCAN_PAGE sent to tab", matchingTab.id);
            autoScanQueuedTabIds.delete(matchingTab.id);
          }
        });
      } else {
        console.log("[LJB] creating search tab", url);
        chrome.tabs.create({ url }, (createdTab) => {
          if (createdTab && createdTab.id) {
            autoScanQueuedTabIds.add(createdTab.id);
          }
        });
      }
    });
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && autoScanQueuedTabIds.has(tabId)) {
    autoScanQueuedTabIds.delete(tabId);
    chrome.tabs.sendMessage(tabId, { type: "AUTO_SCAN_PAGE" }, () => {
      if (chrome.runtime.lastError) {
        console.warn("[LJB] AUTO_SCAN_PAGE failed after load:", chrome.runtime.lastError.message);
      } else {
        console.log("[LJB] AUTO_SCAN_PAGE sent after load to tab", tabId);
      }
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case "POSTS_FOUND":
      updateBadge(message.count || 0);
      break;

    case "JOBS_FOUND":
      updateBadge(message.count || 0);
      break;

    case "APPLIED":
      recordApplication({
        postUrl: message.postUrl,
        role: message.role || "Easy Apply",
        method: "easy_apply",
        status: "Submitted",
        mode: message.mode || "feed"
      });
      break;

    case "EMAIL_SENT":
      recordApplication({
        postUrl: message.postUrl,
        role: message.role || "Email",
        method: "email",
        status: "Drafted",
        mode: "feed"
      });
      break;

    case "SEND_EMAIL":
      sendEmailRequest(message)
        .then(() => sendResponse({ success: true }))
        .catch((error) => sendResponse({ success: false, error: error.message }));
      return true;

    case "GET_SETTINGS":
      LJBStorage.getSettings().then((settings) => sendResponse({ settings }));
      return true;

    case "SCAN_PAGE":
      // Handle scan request from popup
      chrome.tabs.query({ url: ["https://www.linkedin.com/*", "https://linkedin.com/*"] }, (tabs) => {
        console.log("[LJB] SCAN_PAGE from popup, LinkedIn tabs found", tabs?.length);
        if (tabs && tabs.length > 0) {
          const targetTab = tabs.find((tab) => tab.active) || tabs[0];
          chrome.tabs.sendMessage(targetTab.id, { type: "SCAN_PAGE" }, () => {
            if (chrome.runtime.lastError) {
              console.warn("[LJB] Content script not ready:", chrome.runtime.lastError.message);
            } else {
              console.log("[LJB] SCAN_PAGE message sent to tab", targetTab.id);
            }
          });
        } else {
          console.log("[LJB] No LinkedIn tabs open for scan");
        }
      });
      sendResponse({ scanning: true });
      return true;

    case "SCAN_JOBS_PAGE":
      chrome.tabs.query({ url: ["https://www.linkedin.com/*", "https://linkedin.com/*"] }, (tabs) => {
        console.log("[LJB] SCAN_JOBS_PAGE from sidebar, LinkedIn tabs found", tabs?.length);
        if (tabs && tabs.length > 0) {
          const targetTab = tabs.find((tab) => tab.active) || tabs[0];
          chrome.tabs.sendMessage(targetTab.id, { type: "SCAN_JOBS_PAGE" }, () => {
            if (chrome.runtime.lastError) {
              console.warn("[LJB] Content script not ready:", chrome.runtime.lastError.message);
            } else {
              console.log("[LJB] SCAN_JOBS_PAGE message sent to tab", targetTab.id);
            }
          });
        } else {
          console.log("[LJB] No LinkedIn tabs open for jobs scan");
        }
      });
      sendResponse({ scanning: true });
      return true;

    default:
      break;
  }
});

function updateBadge(count) {
  console.log("[LJB] updateBadge", count);
  const text = count > 0 ? String(count) : "";
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color: "#0a66c2" });
  if (count > 0) {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon48.png",
      title: "LinkedIn Job Bot",
      message: `${count} new hiring post${count === 1 ? "" : "s"} found.`
    });
  }
}

async function recordApplication(entry) {
  const settings = await LJBStorage.getSettings();
  const stats = Object.assign({}, settings.stats || {});
  if (entry.method === "easy_apply") {
    stats.totalApplied = Number(stats.totalApplied || 0) + 1;
  } else if (entry.method === "email") {
    stats.totalEmailed = Number(stats.totalEmailed || 0) + 1;
  }
  stats.lastRunAt = new Date().toISOString();
  await LJBStorage.setSync({ stats });

  const local = await LJBStorage.getLocal({ applicationHistory: [] });
  const history = local.applicationHistory || [];
  history.unshift(Object.assign({ date: new Date().toISOString() }, entry));
  await LJBStorage.setLocal({ applicationHistory: history });

  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon48.png",
    title: "LinkedIn Job Bot",
    message: entry.method === "easy_apply" ? `Applied to ${entry.role}.` : `Email sent to ${entry.postUrl || "recruiter"}.`
  });
}

async function sendEmailRequest(message) {
  console.log("[LJB] sendEmailRequest", message);
  const settings = await LJBStorage.getSettings();
  const profile = settings.profile || {};
  const templates = settings.templates || {};
  const template = LJBTemplates.getTemplate(message.role || "business analyst", profile, templates);
  const from = profile.email;
  const to = profile.email;
  const bcc = message.recruiterEmail;

  if (!from || !bcc) {
    throw new Error("Sender or recipient email is missing.");
  }

  const localData = await LJBStorage.getLocal({ resumeAttachment: null });
  const resumeAttachment = localData.resumeAttachment;
  if (resumeAttachment) {
    console.log("[LJB] using resume attachment", resumeAttachment.name);
  }
  await createGmailDraft(from, to, bcc, template.subject, template.body, resumeAttachment);
  await LJBStorage.addEmailedRecruiter(bcc);
  chrome.runtime.sendMessage({ type: "EMAIL_SENT", recruiterEmail: bcc, role: message.role });
}

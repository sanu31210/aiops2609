function $(id) {
  return document.getElementById(id);
}

async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(null, (syncData) => {
      chrome.storage.local.get(["resumeAttachment"], (localData) => {
        resolve({ sync: syncData, local: localData });
      });
    });
  });
}

function setCheckboxes(roles) {
  document.querySelectorAll(".role-checkbox").forEach((checkbox) => {
    checkbox.checked = roles.includes(checkbox.value);
  });
}

function updateRoleList() {
  const customRole = $("customRole").value.trim().toLowerCase();
  if (!customRole) return;
  if (!document.querySelector(`.role-checkbox[value='${customRole}']`)) {
    const wrapper = document.createElement("label");
    wrapper.innerHTML = `<input type="checkbox" value="${customRole}" class="role-checkbox" checked /> ${customRole}`;
    $("roleGroup").appendChild(wrapper);
  }
  $("customRole").value = "";
}

function populateTemplates(templates) {
  $("pmSubject").value = templates["project manager"]?.subject || "";
  $("pmBody").value = templates["project manager"]?.body || "";
  $("baSubject").value = templates["business analyst"]?.subject || "";
  $("baBody").value = templates["business analyst"]?.body || "";
  $("smSubject").value = templates["scrum master"]?.subject || "";
  $("smBody").value = templates["scrum master"]?.body || "";
}

function populateResumeInfo(attachment) {
  if (attachment && attachment.name) {
    $("resumeFileInfo").innerText = `Uploaded resume: ${attachment.name}`;
  } else {
    $("resumeFileInfo").innerText = "No resume uploaded.";
  }
}

function populateForm(settings) {
  const profile = settings.sync.profile || {};
  $("fullName").value = profile.fullName || "";
  $("email").value = profile.email || "";
  $("phone").value = profile.phone || "";
  $("linkedinUrl").value = profile.linkedinUrl || "";
  $("website").value = profile.website || "";
  $("location").value = profile.location || "";
  $("experience").value = profile.experience || "3";
  $("address").value = profile.address || "";
  $("noticePeriod").value = profile.noticePeriod || "2 weeks";
  $("expectedSalary").value = profile.expectedSalary || "";
  $("headline").value = profile.headline || "";
  $("zipcode").value = profile.zipcode || "";
  $("summary").value = profile.summary || "";
  $("resumeUrl").value = profile.resumeUrl || "";

  const preferences = settings.sync.preferences || {};
  setCheckboxes(preferences.roles || []);
  $("keywords").value = (preferences.keywords || []).join(", ");
  $("runInterval").value = preferences.runInterval || 30;
  $("intervalValue").innerText = preferences.runInterval || 30;
  $("autoScrollCount").value = preferences.autoScrollCount || 5;
  $("scrollCountValue").innerText = preferences.autoScrollCount || 5;
  $("autoApply").checked = !!preferences.autoApply;
  $("emailFallback").checked = preferences.emailFallback !== false;
  $("autoScanEnabled").checked = preferences.autoScanEnabled !== false;
  $("easyApplyOnlyMode").checked = !!preferences.easyApplyOnlyMode;
  $("easyApplyAutoMode").checked = !!preferences.easyApplyAutoMode;
  $("easyApplyRateLimit").value = preferences.easyApplyRateLimit || 10;
  $("rateLimitValue").innerText = preferences.easyApplyRateLimit || 10;
  $("aiApiKey").value = settings.sync.aiApiKey || "";
  document.querySelector(`input[name='dateFilter'][value='${preferences.dateFilter || "past-24h"}']`).checked = true;

  populateTemplates(settings.sync.templates || {});
  populateResumeInfo(settings.local.resumeAttachment);
}

function gatherRoles() {
  return Array.from(document.querySelectorAll(".role-checkbox:checked")).map((input) => input.value);
}

function saveSettings() {
  const profile = {
    fullName: $("fullName").value.trim(),
    email: $("email").value.trim(),
    phone: $("phone").value.trim(),
    linkedinUrl: $("linkedinUrl").value.trim(),
    website: $("website").value.trim(),
    location: $("location").value.trim(),
    experience: $("experience").value.trim(),
    address: $("address").value.trim(),
    noticePeriod: $("noticePeriod").value.trim(),
    expectedSalary: $("expectedSalary").value.trim(),
    headline: $("headline").value.trim(),
    zipcode: $("zipcode").value.trim(),
    summary: $("summary").value.trim(),
    resumeUrl: $("resumeUrl").value.trim()
  };

  const preferences = {
    roles: gatherRoles(),
    keywords: $("keywords").value.split(",").map((keyword) => keyword.trim()).filter(Boolean),
    dateFilter: document.querySelector("input[name='dateFilter']:checked").value,
    runInterval: Number($("runInterval").value),
    autoScrollCount: Number($("autoScrollCount").value),
    autoApply: $("autoApply").checked,
    emailFallback: $("emailFallback").checked,
    autoScanEnabled: $("autoScanEnabled").checked,
    easyApplyOnlyMode: $("easyApplyOnlyMode").checked,
    easyApplyAutoMode: $("easyApplyAutoMode").checked,
    easyApplyRateLimit: Number($("easyApplyRateLimit").value)
  };

  const aiApiKey = $("aiApiKey").value.trim();

  const templates = {
    "project manager": { subject: $("pmSubject").value.trim(), body: $("pmBody").value.trim() },
    "business analyst": { subject: $("baSubject").value.trim(), body: $("baBody").value.trim() },
    "scrum master": { subject: $("smSubject").value.trim(), body: $("smBody").value.trim() }
  };

  chrome.storage.sync.set({ profile, preferences, templates, aiApiKey }, () => {
    $("saveMessage").innerText = "Settings saved.";
    setTimeout(() => { $("saveMessage").innerText = ""; }, 1800);
  });
}

function connectGmail() {
  connectGmailFlow().catch((err) => {
    console.error("Gmail flow error:", err);
  });
}

function setResumeAttachment(attachment) {
  chrome.storage.local.set({ resumeAttachment: attachment });
}

function handleResumeUpload(event) {
  const file = event.target.files[0];
  if (!file) {
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    const base64 = reader.result.split(",")[1];
    setResumeAttachment({ name: file.name, type: file.type || "application/pdf", data: base64 });
    populateResumeInfo({ name: file.name });
  };
  reader.readAsDataURL(file);
}

function bindEvents() {
  $("saveButton").addEventListener("click", saveSettings);
  $("connect-gmail").addEventListener("click", () => connectGmail());
  $("customRole").addEventListener("change", updateRoleList);
  $("runInterval").addEventListener("input", (event) => {
    $("intervalValue").innerText = event.target.value;
  });
  $("autoScrollCount").addEventListener("input", (event) => {
    $("scrollCountValue").innerText = event.target.value;
  });
  $("easyApplyRateLimit").addEventListener("input", (event) => {
    $("rateLimitValue").innerText = event.target.value;
  });
  $("resumeFile").addEventListener("change", handleResumeUpload);
  $("clearHistory").addEventListener("click", () => {
    chrome.storage.local.set({ applicationHistory: [] }, () => {
      alert("History cleared");
    });
  });
  $("clearSeenPosts").addEventListener("click", () => {
    chrome.storage.local.set({ seenPosts: [] }, () => {
      alert("Seen posts cleared");
    });
  });
}

function init() {
  loadSettings().then((settings) => {
    populateForm(settings);
    bindEvents();
  });
}

document.addEventListener("DOMContentLoaded", init);

// UTF-8 safe base64url encoder
function utf8ToBase64Url(str) {
  const utf8 = unescape(encodeURIComponent(str));
  const b64 = btoa(utf8);
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

// Build raw MIME (text only). toList = array of recipient emails
function buildRawMessage(from, toList, subject, body) {
  const to = (toList || []).join(", ");
  const mime =
    `From: ${from}\r\n` +
    `To: ${to}\r\n` +
    `Subject: ${subject}\r\n` +
    `Content-Type: text/plain; charset="UTF-8"\r\n` +
    `\r\n` +
    `${body}\r\n`;
  return utf8ToBase64Url(mime);
}

// Get token via chrome.identity (interactive = true for first-time consent)
function getGmailToken(interactive = true) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, (token) => {
      if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
      resolve(token);
    });
  });
}

// Send via Gmail REST API. token = access token from getGmailToken
async function sendGmail(token, from, toList, subject, body) {
  const raw = buildRawMessage(from, toList, subject, body);
  const res = await fetch("https://www.googleapis.com/gmail/v1/users/me/messages/send", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ raw })
  });
  if (!res.ok) {
    const err = await res.text().catch(()=>null);
    throw new Error(`Gmail send failed: ${res.status} ${res.statusText} ${err}`);
  }
  return res.json();
}

// Use when user clicks Connect Gmail (replace existing connectGmail or keep to call this)
async function connectGmailFlow() {
  try {
    const token = await getGmailToken(true);
    // Optionally save a flag for UI
    chrome.storage.local.set({ gmail_connected: true });
    $("gmail-status").innerText = "Gmail connected.";
    return token;
  } catch (err) {
    $("gmail-status").innerText = "Gmail connection failed.";
    throw err;
  }
}

// Call this from your email send flow for a post (non-interactive attempt first)
async function sendForPost(fromEmail, toList, subject, body) {
  try {
    let token = await getGmailToken(false).catch(() => null);
    if (!token) token = await getGmailToken(true); // interactive if needed
    return await sendGmail(token, fromEmail, toList, subject, body);
  } catch (err) {
    console.error("sendForPost error", err);
    throw err;
  }
}

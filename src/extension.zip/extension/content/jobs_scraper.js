(function () {
  let isScanning = false;

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function normalize(value) {
    return (value || "").toLowerCase();
  }

  function isJobsPage() {
    return window.location.href.includes("/jobs/search/") || 
           window.location.href.includes("/jobs/");
  }

  function findJobCards() {
    function isVisibleElement(el) {
      if (!el) return false;
      const hidden = el.className?.includes("visually-hidden") || 
                     el.getAttribute("aria-hidden") === "true" || 
                     el.hasAttribute("hidden");
      if (hidden) return false;
      const style = window.getComputedStyle(el);
      if (style.visibility === "hidden" || style.display === "none" || style.opacity === "0") return false;
      const rect = el.getBoundingClientRect();
      return el.offsetParent !== null && rect.width > 10 && rect.height > 10;
    }

    let main = document.querySelector("[role='main']") || 
               document.querySelector(".scaffold-finite-scroll__content") ||
               document.querySelector(".scaffold-layout__main") ||
               document.querySelector("main");

    if (!main) {
      console.log("[LJB Jobs] No main container found, using document");
      main = document;
    }

    console.log("[LJB Jobs] Main container found:", main.className || main.tagName);

    // Try to find the jobs list container first
    const jobsList = main.querySelector(".jobs-search-results__list, .scaffold-layout__list, ul");
    const searchContainer = jobsList || main;

    const probeSelectors = [
      ".jobs-search-results__list-item",
      "li[data-occludable-job-id]",
      ".job-card-container",
      ".job-card-list",
      "[class*='job-card-list']",
      "[class*='job-search']",
      "li.reusable-search__result-container"
    ];

    const rawCards = [];
    for (const sel of probeSelectors) {
      rawCards.push(...searchContainer.querySelectorAll(sel));
    }

    let cards = Array.from(new Set(rawCards)).filter((card) => {
      const text = card.innerText || "";
      const isVisible = card.offsetParent !== null;
      const isNested = rawCards.some((other) => other !== card && other.contains(card));
      return text.length > 50 && isVisible && !isNested;
    });

    console.log("[LJB Jobs] Candidate job cards found:", cards.length);

    if (cards.length === 0) {
      // Fallback: look for elements with job-card-list__entity-lockup class
      const entityLockups = searchContainer.querySelectorAll(".job-card-list__entity-lockup");
      cards = Array.from(entityLockups).map(lockup => {
        // Get the parent li element that contains the full card
        const parentLi = lockup.closest("li");
        if (parentLi) return parentLi;
        // If no li, return the lockup's parent container
        return lockup.parentElement;
      }).filter(card => card && card.innerText && card.innerText.length > 50);

      const seen = new Set();
      cards = cards.filter(card => {
        for (const existing of seen) {
          if (existing.contains(card)) return false;
        }
        seen.add(card);
        return true;
      }).slice(0, 50);

      console.log("[LJB Jobs] Entity lockup fallback job cards found:", cards.length);
    }

    // Ultimate fallback: look for any element with job-related text
    if (cards.length === 0) {
      console.log("[LJB Jobs] Using ultimate fallback - searching for job-related elements");
      const allDivs = searchContainer.querySelectorAll("div, li");
      cards = Array.from(allDivs).filter(div => {
        const text = (div.innerText || "").toLowerCase();
        const hasJobKeywords = text.includes("job") || text.includes("apply") || text.includes("company") || text.includes("location");
        const hasLink = div.querySelector("a[href*='/jobs/view/']");
        const isVisible = div.offsetParent !== null;
        return hasJobKeywords && hasLink && isVisible && text.length > 50;
      });

      const seen = new Set();
      cards = cards.filter(card => {
        for (const existing of seen) {
          if (existing.contains(card)) return false;
        }
        seen.add(card);
        return true;
      }).slice(0, 50);

      console.log("[LJB Jobs] Ultimate fallback job cards found:", cards.length);
    }

    return cards.filter(card => {
      const text = card.innerText || "";
      const isVisible = card.offsetParent !== null;
      return text.length > 50 && isVisible;
    });
  }

  function hasEasyApply(card) {
    // Check all footer items in the card for Easy Apply
    const footerItems = card.querySelectorAll(".job-card-container__footer-item, li[class*='footer']");
    for (const item of footerItems) {
      const footerText = (item.innerText || "").toLowerCase();
      if (footerText === "easy apply" || footerText.indexOf("easy apply") !== -1) {
        return true;
      }
    }

    // Look for apply buttons with various selectors
    const applyButton = card.querySelector(
      "button[aria-label*='Easy Apply'], button[aria-label*='Apply'], " +
      "button[data-control-name*='easy_apply'], button[data-test-id*='apply'], " +
      ".jobs-apply-button, a[href*='apply']"
    );
    return Boolean(applyButton);
  }

  function getJobUrl(card) {
    const linkEl = card.querySelector("a[href*='/jobs/view/']");
    return linkEl?.href || null;
  }

  function getJobDetails(card) {
    const titleEl = card.querySelector("h3, .job-card-list__title, [class*='job-title'], [class*='title']");
    const title = titleEl?.innerText?.trim() || "";

    const companyEl = card.querySelector("h4, .job-card-container__company-name, [class*='company']");
    const company = companyEl?.innerText?.trim() || "";

    const locationEl = card.querySelector(".job-card-container__metadata-item, [class*='location'], [class*='metadata']");
    const location = locationEl?.innerText?.trim() || "";

    const linkEl = card.querySelector("a[href*='/jobs/view/']");
    const jobUrl = linkEl?.href || null;

    const descriptionEl = card.querySelector(".job-card-container__description, [class*='description']");
    const description = descriptionEl?.innerText?.trim() || "";

    return { title, company, location, jobUrl, description };
  }

  function jobMatchesPreferences(jobDetails, preferences) {
    const normalizedTitle = normalize(jobDetails.title);
    const normalizedDescription = normalize(jobDetails.description);
    const combinedText = `${normalizedTitle} ${normalizedDescription}`;

    const roleMatch = preferences.roles.some((role) => combinedText.includes(normalize(role)));
    const keywordMatch = preferences.keywords.some((keyword) => combinedText.includes(normalize(keyword)));

    return roleMatch || keywordMatch;
  }

  async function scanJobsPage() {
    if (isScanning) {
      console.log("[LJB Jobs] scanJobsPage already running, skipping");
      return [];
    }
    isScanning = true;
    console.log("[LJB Jobs] scanJobsPage started");
    console.log("[LJB Jobs] Current URL:", window.location.href);

    const settings = await LJBStorage.getSettings();
    const preferences = settings.preferences;
    const appliedJobs = await LJBStorage.getAppliedJobs();

    const cards = findJobCards();
    console.log("[LJB Jobs] job cards found:", cards.length);

    const matches = [];

    for (const card of cards) {
      if (!hasEasyApply(card)) {
        console.log("[LJB Jobs] Skipping job - no Easy Apply available");
        continue;
      }

      const jobDetails = getJobDetails(card);
      if (!jobDetails.jobUrl) {
        console.log("[LJB Jobs] Skipping job - no job URL found");
        continue;
      }

      if (appliedJobs.includes(jobDetails.jobUrl)) {
        console.log("[LJB Jobs] Skipping already applied job:", jobDetails.jobUrl);
        continue;
      }

      if (!jobMatchesPreferences(jobDetails, preferences)) {
        continue;
      }
      matches.push({
        jobUrl: jobDetails.jobUrl,
        title: jobDetails.title,
        company: jobDetails.company,
        location: jobDetails.location,
        description: jobDetails.description,
        easyApply: true
      });
    }

    console.log("[LJB Jobs] matching jobs found:", matches.length);

    if (matches.length) {
      console.log("[LJB Jobs] Sending JOBS_FOUND message with", matches.length, "jobs");
      window.postMessage({ type: "JOBS_FOUND", jobs: matches }, "*");
      console.log("[LJB Jobs] Message sent via window.postMessage");
    }

    isScanning = false;
    return matches;
  }

  function observeJobsPage() {
    if (!isJobsPage()) {
      console.log("[LJB Jobs] Not on jobs page, skipping observation");
      return;
    }

    let root = document.querySelector("[role='main']") || 
               document.querySelector(".scaffold-finite-scroll__content") ||
               document.querySelector("main");

    if (!root) {
      console.log("[LJB Jobs] Could not find visible jobs container for observation");
      return;
    }

    console.log("[LJB Jobs] Starting jobs page observation");

    const observer = new MutationObserver(async () => {
      await delay(2000);
      scanJobsPage();
    });

    observer.observe(root, { childList: true, subtree: true });
  }

  async function autoScrollJobs(count = 2) {
    const scrollable = document.scrollingElement || document.documentElement;
    for (let i = 0; i < count; i += 1) {
      scrollable.scrollBy({ top: 1200, behavior: "smooth" });
      await delay(1800);
    }
  }

  async function autoScanJobs(count = 5) {
    console.log("[LJB Jobs] autoScanJobs starting with scroll count:", count);
    await autoScrollJobs(count);
    await delay(1500);
    return await scanJobsPage();
  }

  window.jobsScraper = { 
    scanJobsPage, 
    autoScanJobs,
    isJobsPage
  };

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "SCAN_JOBS_PAGE") {
      scanJobsPage().then((matches) => sendResponse({ matches }));
      return true;
    }
    if (message.type === "AUTO_SCAN_JOBS_PAGE") {
      LJBStorage.getSettings().then((settings) => {
        const scrollCount = Number(settings.preferences.autoScrollCount || 5);
        autoScanJobs(scrollCount).then((matches) => sendResponse({ matches }));
      });
      return true;
    }
  });

  function initJobsScraper() {
    if (isJobsPage()) {
      console.log("[LJB Jobs] Initializing on jobs page");
      scanJobsPage();
      observeJobsPage();
      autoScrollJobs();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initJobsScraper);
  } else {
    initJobsScraper();
  }
})();

// Global message listener to catch all window.postMessage messages
window.addEventListener("message", (event) => {
  console.log("[LJB Sidebar Global] Received window message:", event.data?.type);
  if (event.data && event.data.type === "JOBS_FOUND") {
    console.log("[LJB Sidebar Global] JOBS_FOUND with", event.data.jobs?.length, "jobs");
    // Try to call renderMatches if window.ljbSidebar exists
    if (window.ljbSidebar && event.data.jobs && event.data.jobs.length > 0) {
      console.log("[LJB Sidebar Global] Calling renderMatches via window.ljbSidebar");
      window.ljbSidebar.updateMatches(event.data.jobs);
    }
  }
});

(function () {
  console.log("[LJB Sidebar] Script loaded");
  let matches = [];
  let currentMode = "feed"; // "feed" or "jobs"

  async function getCurrentMode() {
    const settings = await LJBStorage.getSettings();
    const preferences = settings.preferences || {};
    if (preferences.easyApplyOnlyMode) {
      return "jobs";
    }
    return "feed";
  }

  function isJobsPage() {
    return window.location.href.includes("/jobs/search/") || window.location.href.includes("/jobs/");
  }

  async function updateMode() {
    const mode = await getCurrentMode();
    currentMode = mode;
    const header = document.getElementById("ljb-title");
    const scanBtn = document.getElementById("ljb-scan-btn");
    
    if (header) {
      header.innerText = mode === "jobs" ? "Easy Apply Bot" : "Job Bot";
    }
    
    if (scanBtn) {
      if (mode === "jobs") {
        scanBtn.innerText = isJobsPage() ? "Scan Jobs" : "Go to Jobs";
      } else {
        scanBtn.innerText = "Scan page";
      }
    }
  }

  function createSidebar() {
    if (document.getElementById("ljb-sidebar")) {
      return;
    }

    const sidebar = document.createElement("div");
    sidebar.id = "ljb-sidebar";
    sidebar.innerHTML = `
      <div id="ljb-header">
        <span id="ljb-title">Job Bot</span>
        <span id="ljb-count">0 matches</span>
        <button id="ljb-toggle">−</button>
      </div>
      <div id="ljb-body"></div>
      <div id="ljb-footer">
        <button id="ljb-scan-btn">Scan page</button>
        <button id="ljb-start-flow-btn" style="display: none;">Start Easy Apply Flow</button>
      </div>
      <div id="ljb-progress" style="display: none; padding: 8px 14px; border-top: 1px solid #e5ecf8; font-size: 12px;"></div>
    `;
    document.body.appendChild(sidebar);
    sidebar.querySelector("#ljb-toggle").addEventListener("click", toggleSidebar);
    sidebar.querySelector("#ljb-scan-btn").addEventListener("click", handleScanClick);
    sidebar.querySelector("#ljb-start-flow-btn").addEventListener("click", handleStartFlow);
  }

  function toggleSidebar() {
    document.getElementById("ljb-sidebar").classList.toggle("ljb-collapsed");
  }

  async function handleScanClick() {
    if (currentMode === "jobs" && !isJobsPage()) {
      const settings = await LJBStorage.getSettings();
      const preferences = settings.preferences || {};
      const keywords = (preferences.keywords || []).join(" ");
      const jobsUrl = `https://www.linkedin.com/jobs/search/?keywords=${encodeURIComponent(keywords)}&f_JT=F`;
      window.location.href = jobsUrl;
      return;
    }

    if (currentMode === "jobs") {
      chrome.runtime.sendMessage({ type: "SCAN_JOBS_PAGE" });
    } else {
      chrome.runtime.sendMessage({ type: "SCAN_PAGE" });
    }
  }

  async function handleStartFlow() {
    const settings = await LJBStorage.getSettings();
    const preferences = settings.preferences || {};
    const autoMode = preferences.easyApplyAutoMode;

    if (!isJobsPage()) {
      const keywords = (preferences.keywords || []).join(" ");
      const jobsUrl = `https://www.linkedin.com/jobs/search/?keywords=${encodeURIComponent(keywords)}&f_JT=F`;
      window.location.href = jobsUrl;
      return;
    }

    if (autoMode) {
      startAutomaticFlow();
    } else {
      startManualFlow();
    }
  }

  async function startAutomaticFlow() {
    const progressDiv = document.getElementById("ljb-progress");
    progressDiv.style.display = "block";
    progressDiv.innerText = "Starting automatic flow...";

    const settings = await LJBStorage.getSettings();
    const profile = settings.profile || {};
    const localData = await LJBStorage.getLocal({ resumeAttachment: null });
    const resumeAttachment = localData.resumeAttachment;

    // Store all jobs for sequential processing
    await chrome.storage.local.set({ ljb_autoApplyQueue: matches, ljb_autoApplyIndex: 0, profile, resumeAttachment });

    // Start with the first job
    if (matches.length > 0) {
      const firstJob = matches[0];
      await chrome.storage.local.set({ ljb_pendingApply: { postUrl: firstJob.jobUrl, profile, jobDetails: firstJob, resumeAttachment, timestamp: Date.now() } });
      progressDiv.innerText = `Navigating to job 1 of ${matches.length}: ${firstJob.title} at ${firstJob.company}`;
      window.location.href = firstJob.jobUrl;
    } else {
      progressDiv.innerText = "No jobs to apply to!";
      setTimeout(() => { progressDiv.style.display = "none"; }, 3000);
    }
  }

  async function startManualFlow() {
    const progressDiv = document.getElementById("ljb-progress");
    progressDiv.style.display = "block";
    progressDiv.innerText = "Manual flow - click Apply on each job";
    setTimeout(() => { progressDiv.style.display = "none"; }, 3000);
  }

  function renderMatches(newMatches) {
    matches = newMatches;
    const body = document.getElementById("ljb-body");
    body.innerHTML = "";
    document.getElementById("ljb-count").innerText = `${matches.length} match${matches.length === 1 ? "" : "es"}`;

    // Show/hide start flow button based on mode
    const startFlowBtn = document.getElementById("ljb-start-flow-btn");
    if (startFlowBtn) {
      startFlowBtn.style.display = currentMode === "jobs" ? "inline-block" : "none";
    }

    matches.forEach((match, index) => {
      const card = document.createElement("div");
      card.className = currentMode === "jobs" ? "ljb-job-card" : "ljb-post-card";
      card.dataset.index = index;

      if (currentMode === "jobs") {
        // Job card rendering
        card.innerHTML = `
          <div class="ljb-job-title">${match.title || "Job Title"}</div>
          <div class="ljb-job-company">${match.company || "Company"}</div>
          <div class="ljb-job-location">${match.location || "Location"}</div>
          <div class="ljb-job-actions">
            <button class="ljb-apply-btn">Apply</button>
            <button class="ljb-skip-btn">Skip</button>
          </div>
          <div class="ljb-job-status"></div>
        `;
        card.querySelector(".ljb-apply-btn").addEventListener("click", () => handleJobApply(index));
        card.querySelector(".ljb-skip-btn").addEventListener("click", () => handleJobSkip(index));
      } else {
        // Feed post card rendering (existing)
        const emailList = Array.isArray(match.recruiterEmails) && match.recruiterEmails.length > 0
          ? match.recruiterEmails.join(", ")
          : "Hiring post";
        card.innerHTML = `
          <div class="ljb-post-author">${emailList}</div>
          <div class="ljb-post-preview">${match.preview}</div>
          <div class="ljb-post-actions">
            <button class="ljb-apply-btn">Easy Apply</button>
            <button class="ljb-skip-btn">Skip</button>
          </div>
          <div class="ljb-email-actions" style="margin-top: 8px;"></div>
          <div class="ljb-post-status"></div>
        `;
        card.querySelector(".ljb-apply-btn").addEventListener("click", () => handleApply(index));
        card.querySelector(".ljb-skip-btn").addEventListener("click", () => handleSkip(index));
        
        const emailActionsContainer = card.querySelector(".ljb-email-actions");
        if (Array.isArray(match.recruiterEmails) && match.recruiterEmails.length > 0) {
          match.recruiterEmails.forEach((email) => {
            const emailBtn = document.createElement("button");
            emailBtn.className = "ljb-email-btn";
            emailBtn.textContent = `Email: ${email.split("@")[0]}`;
            emailBtn.style.marginRight = "4px";
            emailBtn.addEventListener("click", () => handleEmail(index, email));
            emailActionsContainer.appendChild(emailBtn);
          });
        } else {
          emailActionsContainer.innerHTML = "<div style='font-size: 12px; color: #999;'>No recruiter email</div>";
        }
      }
      
      body.appendChild(card);
    });
  }

  function setStatus(index, text) {
    const card = document.querySelector(`.ljb-post-card[data-index='${index}'], .ljb-job-card[data-index='${index}']`);
    if (!card) return;
    const statusEl = card.querySelector(".ljb-post-status, .ljb-job-status");
    if (statusEl) statusEl.innerText = text;
  }

  function removeMatch(index) {
    matches = matches.filter((_, idx) => idx !== index);
    renderMatches(matches);
  }

  async function handleApply(index) {
    const match = matches[index];
    if (!match) return;
    const profile = (await LJBStorage.getSettings()).profile;
    setStatus(index, "Applying...");
    try {
      // Store pending apply data before navigation
      const pendingData = { postUrl: match.postUrl, profile, jobDetails: match, resumeAttachment: null, timestamp: Date.now() };
      console.log("[LJB Sidebar] Storing pending apply data:", pendingData);
      await chrome.storage.local.set({ ljb_pendingApply: pendingData });
      // Verify storage
      const verify = await chrome.storage.local.get(["ljb_pendingApply"]);
      console.log("[LJB Sidebar] Storage verification:", verify.ljb_pendingApply ? "SUCCESS" : "FAILED");
      const result = await window.LJB.applyToJob(match.postUrl, profile);
      if (result.success) {
        setStatus(index, "Applied ✓");
        chrome.runtime.sendMessage({ type: "APPLIED", postUrl: match.postUrl, role: "Easy Apply" });
        await LJBStorage.addSeenPost(match.postUrl);
        removeMatch(index);
      } else if (result.method === "redirect") {
        setStatus(index, "Opening job page...");
        // Don't remove the match - let the user navigate and apply manually
      } else {
        setStatus(index, "Failed to auto-apply");
      }
    } catch (error) {
      console.error("[LJB Sidebar] Apply error:", error);
      setStatus(index, "Apply error");
    }
  }

  async function handleJobApply(index) {
    const match = matches[index];
    if (!match) return;
    const settings = await LJBStorage.getSettings();
    const profile = settings.profile || {};
    const localData = await LJBStorage.getLocal({ resumeAttachment: null });
    const resumeAttachment = localData.resumeAttachment;
    setStatus(index, "Applying...");
    try {
      // Store pending apply data before navigation
      const pendingData = { postUrl: match.jobUrl, profile, jobDetails: match, resumeAttachment, timestamp: Date.now() };
      console.log("[LJB Sidebar] Storing pending apply data (JobApply):", pendingData);
      await chrome.storage.local.set({ ljb_pendingApply: pendingData });
      // Verify storage
      const verify = await chrome.storage.local.get(["ljb_pendingApply"]);
      console.log("[LJB Sidebar] Storage verification:", verify.ljb_pendingApply ? "SUCCESS" : "FAILED");
      const result = await window.LJB.applyToJob(match.jobUrl, profile, match, resumeAttachment);
      if (result.success) {
        setStatus(index, "Applied ✓");
        chrome.runtime.sendMessage({ type: "APPLIED", postUrl: match.jobUrl, role: match.title, mode: "easy_apply_only" });
        await LJBStorage.addAppliedJob(match.jobUrl);
        removeMatch(index);
      } else if (result.method === "redirect") {
        setStatus(index, "Opening job page...");
        // Don't remove the match - let the user navigate and apply manually
      } else {
        setStatus(index, "Failed to auto-apply");
      }
    } catch (error) {
      setStatus(index, "Apply error");
    }
  }

  async function handleJobSkip(index) {
    const match = matches[index];
    if (!match) return;
    await LJBStorage.addAppliedJob(match.jobUrl);
    removeMatch(index);
  }

  async function handleEmail(index, recruiterEmail) {
    const match = matches[index];
    if (!match || !recruiterEmail) return;
    const profile = (await LJBStorage.getSettings()).profile;
    setStatus(index, `Sending to ${recruiterEmail}...`);
    chrome.runtime.sendMessage({
      type: "SEND_EMAIL",
      recruiterEmail,
      role: "email",
      profile,
      postUrl: match.postUrl
      }, (response) => {
      if (response && response.success) {
        setStatus(index, "Draft created ✓");
        // Disable the clicked email button
        const card = document.querySelector(`.ljb-post-card[data-index='${index}']`);
        if (card) {
          const emailBtn = Array.from(card.querySelectorAll('.ljb-email-btn')).find(btn => btn.textContent.includes(recruiterEmail.split('@')[0]));
          if (emailBtn) {
            emailBtn.disabled = true;
            emailBtn.style.opacity = '0.5';
            emailBtn.textContent += ' ✓';
          }
          // Check if all email buttons are disabled
          const allEmailBtns = card.querySelectorAll('.ljb-email-btn');
          const allDisabled = Array.from(allEmailBtns).every(btn => btn.disabled);
          if (allDisabled) {
            // All emails sent, remove the post
            LJBStorage.addSeenPost(match.postUrl);
            removeMatch(index);
          }
        }
      } else {
        setStatus(index, `Draft failed: ${response.error || "unknown"}`);
      }
    });
  }

  async function handleSkip(index) {
    const match = matches[index];
    if (!match) return;
    await LJBStorage.addSeenPost(match.postUrl);
    removeMatch(index);
  }

  window.ljbSidebar = { updateMatches: renderMatches };

  async function initSidebar() {
    console.log("[LJB Sidebar] Initializing sidebar");
    createSidebar();
    await updateMode();
    console.log("[LJB Sidebar] Sidebar initialized, setting up message listener");
    
    // Listen for jobs scraper results
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      console.log("[LJB Sidebar] Received message:", message.type, "from:", sender);
      if (message.type === "JOBS_FOUND") {
        console.log("[LJB Sidebar] Jobs found:", message.jobs?.length);
        if (message.jobs && message.jobs.length > 0) {
          console.log("[LJB Sidebar] Rendering matches");
          renderMatches(message.jobs);
        }
      }
      return true; // Keep message channel open for async response
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initSidebar);
  } else {
    initSidebar();
  }
})();

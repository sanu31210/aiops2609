(function () {
  // Guard flag to prevent concurrent apply attempts
  let isApplying = false;

  /*
  // Language fix temporarily disabled - may be causing issues
  // Detect and fix Arabic language redirect issue
  function checkAndFixLanguage() {
    const html = document.documentElement;
    const currentLang = html.getAttribute('lang') || html.getAttribute('xml:lang') || '';
    const bodyText = document.body ? document.body.innerText : '';
    
    // Check for Arabic language indicator or RTL text
    const isArabic = currentLang.includes('ar') || 
                     /[\u0600-\u06FF]/.test(bodyText) || 
                     bodyText.includes('\u200F') || // RTL mark
                     bodyText.includes('\u202B') || // RTL embed
                     bodyText.includes('\u202E');   // RTL override
    
    if (isArabic && !window.location.search.includes('lang=en')) {
      // Check if we've already tried to fix this URL to prevent infinite loop
      const reloadKey = 'ljb_lang_fix_' + window.location.pathname;
      if (sessionStorage.getItem(reloadKey)) {
        console.log("[LJB Easy Apply] Already attempted language fix for this page, skipping to prevent loop");
        return false;
      }
      
      console.log("[LJB Easy Apply] Detected Arabic language, forcing English reload");
      sessionStorage.setItem(reloadKey, 'true');
      const url = new URL(window.location.href);
      url.searchParams.set('lang', 'en');
      document.cookie = "li_lang=en_US; path=/; domain=.linkedin.com";
      window.location.href = url.toString();
      return true;
    }
    return false;
  }

  // Run language check on page load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', checkAndFixLanguage);
  } else {
    checkAndFixLanguage();
  }

  // Set up MutationObserver to detect language changes after LinkedIn's redirect
  let languageCheckScheduled = false;
  const observer = new MutationObserver(() => {
    if (!languageCheckScheduled) {
      languageCheckScheduled = true;
      setTimeout(() => {
        checkAndFixLanguage();
        languageCheckScheduled = false;
      }, 1000);
    }
  });
  */

  /*
  // Observe body content changes
  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
      }
    });
  }
  */

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function dispatchInput(input, value) {
    if (!input || value === undefined || value === null) {
      return;
    }
    input.focus();
    input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function findField(label) {
    // Restrict search to Easy Apply modal only
    const modal = document.querySelector('.jobs-easy-apply-modal, .artdeco-modal__content, .jobs-apply-form');
    if (!modal) return null;
    const candidates = Array.from(modal.querySelectorAll("label, span, div")).filter((node) => {
      const text = (node.innerText || "").toLowerCase();
      return text.includes(label.toLowerCase());
    });

    for (const candidate of candidates) {
      const field = candidate.querySelector("input, textarea, select");
      if (field && modal.contains(field)) return field;
      const forId = candidate.getAttribute("for");
      if (forId) {
        const fieldById = modal.querySelector(`#${forId}`);
        if (fieldById) return fieldById;
      }
      const sibling = candidate.nextElementSibling && candidate.nextElementSibling.querySelector("input, textarea, select");
      if (sibling && modal.contains(sibling)) return sibling;
    }
    return null;
  }

  function findFieldByQuestionContainer(modal) {
    // Find all question containers in the modal, or entire document if modal not provided
    const searchRoot = modal || document.body;
    console.log("[LJB EasyApply] Searching for questions in:", modal ? "modal" : "document body");
    
    const questionContainers = searchRoot.querySelectorAll('[data-test-form-element], .jobs-easy-apply-form-element, .artdeco-text-input--container, fieldset, .jobs-easy-apply-modal__content > div > div');
    console.log("[LJB EasyApply] Found", questionContainers.length, "question containers");
    
    let questions = Array.from(questionContainers).map(container => {
      const labelEl = container.querySelector('label, .artdeco-text-input--label, legend, .t-14');
      const label = labelEl?.innerText?.trim() || container.querySelector('span')?.innerText?.trim() || "Unknown";
      const select = container.querySelector('select');
      const radio = container.querySelector('fieldset[data-test-form-builder-radio-button-form-component="true"], input[type="radio"]');
      const text = container.querySelector('input[type="text"], input[type="email"], input[type="tel"], input[type="number"]');
      const textarea = container.querySelector('textarea');
      const checkbox = container.querySelector('input[type="checkbox"]');
      return { container, label, select, radio, text, textarea, checkbox };
    }).filter(q => q.select || q.radio || q.text || q.textarea || q.checkbox);
    
    // If no questions found, try broader search - but only look for visible elements
    // and filter out search bars and other UI elements
    if (questions.length === 0) {
      console.log("[LJB EasyApply] No structured questions found, trying broader input search");
      const allInputs = searchRoot.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([placeholder*="Search"]), select, textarea');
      console.log("[LJB EasyApply] Found", allInputs.length, "raw input elements");
      
      questions = Array.from(allInputs)
        .filter(input => {
          // Filter out elements that are clearly not Easy Apply form fields
          const placeholder = (input.placeholder || '').toLowerCase();
          const ariaLabel = (input.getAttribute('aria-label') || '').toLowerCase();
          const isSearch = placeholder.includes('search') || ariaLabel.includes('search');
          const isLanguage = placeholder.includes('language') || ariaLabel.includes('language');
          const isVisible = input.offsetParent !== null; // Check if element is visible
          return !isSearch && !isLanguage && isVisible;
        })
        .map(input => {
          const labelEl = searchRoot.querySelector(`label[for="${input.id}"]`) || 
                         input.closest('div')?.querySelector('label, span, .t-14');
          const label = labelEl?.innerText?.trim() || input.placeholder || input.name || "Unknown";
          return { 
            container: input.closest('div'), 
            label, 
            select: input.tagName === 'SELECT' ? input : null, 
            radio: input.type === 'radio' ? input : null, 
            text: input.type === 'text' || input.type === 'email' || input.type === 'tel' || input.type === 'number' ? input : null, 
            textarea: input.tagName === 'TEXTAREA' ? input : null, 
            checkbox: input.type === 'checkbox' ? input : null 
          };
        });
    }
    
    console.log("[LJB EasyApply] Filtered to", questions.length, "fields with inputs");
    return questions;
  }

  function fuzzyMatch(target, options) {
    const targetLower = target.toLowerCase();
    for (const option of options) {
      const optionLower = option.toLowerCase();
      if (targetLower === optionLower) return option;
      if (targetLower.includes(optionLower) || optionLower.includes(targetLower)) return option;
    }
    return null;
  }

  function nameParts(fullName) {
    const parts = (fullName || "").trim().split(" ");
    return {
      first: parts[0] || "",
      last: parts.slice(1).join(" ") || ""
    };
  }

  async function fillFormWithAI(profile, jobDetails, resumeAttachment) {
    console.log("[LJB EasyApply] Attempting AI-powered form fill");
    const settings = await LJBStorage.getSettings();
    const preferences = settings.preferences || {};
    const useAI = preferences.easyApplyOnlyMode && typeof LJBAIHelper !== 'undefined';

    if (!useAI) {
      console.log("[LJB EasyApply] AI not enabled, using standard fill");
      return await fillForm(profile);
    }

    const formFields = [];
    const fieldLabels = ["first name", "last name", "email", "phone", "linkedin", "cover letter"];
    
    for (const label of fieldLabels) {
      const field = findField(label);
      if (field) {
        formFields.push({ label, type: field.type || "text" });
      }
    }

    if (formFields.length === 0) {
      console.log("[LJB EasyApply] No fields found for AI fill");
      return await fillForm(profile);
    }

    const resumeData = resumeAttachment ? { name: resumeAttachment.name, data: resumeAttachment.data } : null;
    console.log("[LJB EasyApply] Attempting AI fill...");
    const aiResult = await LJBAIHelper.fillFormWithAI(formFields, resumeData, jobDetails, profile);

    if (aiResult) {
      console.log("[LJB EasyApply] AI fill successful:", aiResult);
      for (const [label, value] of Object.entries(aiResult)) {
        const field = findField(label);
        if (field && value) {
          dispatchInput(field, value);
        }
      }
    } else {
      console.log("[LJB EasyApply] AI fill failed or returned null, using standard fill");
      await fillForm(profile);
    }
  }

  async function fillForm(profile) {
    console.log("[LJB EasyApply] fillForm called with profile:", profile.fullName);
    const parts = nameParts(profile.fullName);
    const modal = findApplyModal();
    
    let questions = [];
    if (modal) {
      console.log("[LJB EasyApply] Modal found, searching for question containers");
      questions = findFieldByQuestionContainer(modal);
    } else {
      console.log("[LJB EasyApply] No modal found, searching entire document for form fields");
      questions = findFieldByQuestionContainer(null); // null means search document.body
    }
    
    if (questions.length === 0) {
      console.log("[LJB EasyApply] No questions found anywhere on page");
      return;
    }
    console.log("[LJB EasyApply] Found", questions.length, "questions to answer");

    // Extract profile data for field mapping
    const fullName = profile.fullName || "";
    const firstName = parts.first;
    const lastName = parts.last;
    const email = profile.email || "";
    const phone = profile.phone || "";
    const linkedin = profile.linkedinUrl || "";
    const website = profile.website || "";
    const location = profile.location || "";
    const summary = profile.summary || "";

    for (const question of questions) {
      const labelLower = question.label.toLowerCase();
      const fieldType = question.select ? 'select' : question.radio ? 'radio' : question.text ? 'text' : question.textarea ? 'textarea' : question.checkbox ? 'checkbox' : 'unknown';
      console.log(`[LJB EasyApply] Processing ${fieldType} question: "${question.label}"`);

      // Handle select/dropdown questions
      if (question.select) {
        const select = question.select;
        const options = Array.from(select.options).map(opt => opt.text);
        let answer = "Yes";

        // Label-based mapping for select questions
        if (labelLower.includes('email') || labelLower.includes('phone')) {
          answer = select.options[select.selectedIndex]?.text || options[0];
        } else if (labelLower.includes('gender') || labelLower.includes('sex')) {
          answer = "Prefer not to say";
        } else if (labelLower.includes('disability')) {
          answer = "No, I don't have a disability";
        } else if (labelLower.includes('proficiency')) {
          answer = "Professional";
        } else if (labelLower.includes('location') || labelLower.includes('city') || labelLower.includes('state') || labelLower.includes('country')) {
          if (labelLower.includes('country')) {
            answer = location.split(',').pop().trim() || options[0];
          } else if (labelLower.includes('state')) {
            answer = location.split(',').slice(-2)[0]?.trim() || options[0];
          } else {
            answer = location || options[0];
          }
        } else if (labelLower.includes('sponsorship') || labelLower.includes('visa')) {
          answer = "No";
        }

        // Try to select the answer
        const matchedOption = fuzzyMatch(answer, options);
        if (matchedOption) {
          for (let i = 0; i < select.options.length; i++) {
            if (select.options[i].text === matchedOption) {
              select.selectedIndex = i;
              select.dispatchEvent(new Event("change", { bubbles: true }));
              console.log("[LJB EasyApply] Selected:", matchedOption, "for:", question.label);
              break;
            }
          }
        } else {
          // Fallback to first valid option
          if (select.selectedIndex === 0) {
            select.selectedIndex = 1;
            select.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }
        continue;
      }

      // Handle radio button questions
      if (question.radio) {
        const radio = question.radio;
        const radioInputs = radio.querySelectorAll('input[type="radio"]');
        let answer = "Yes";

        if (labelLower.includes('citizenship') || labelLower.includes('employment eligibility')) {
          answer = "Yes, I am authorized";
        } else if (labelLower.includes('veteran') || labelLower.includes('protected')) {
          answer = "I am not a protected veteran";
        } else if (labelLower.includes('disability') || labelLower.includes('handicapped')) {
          answer = "No, I don't have a disability";
        } else if (labelLower.includes('sponsorship') || labelLower.includes('visa')) {
          answer = "No";
        }

        // Try to find and click the matching radio option
        for (const input of radioInputs) {
          const label = radio.querySelector(`label[for="${input.id}"]`);
          if (label && label.innerText.toLowerCase().includes(answer.toLowerCase())) {
            input.click();
            console.log("[LJB EasyApply] Selected radio:", answer, "for:", question.label);
            break;
          }
        }
        continue;
      }

      // Handle text input questions
      if (question.text) {
        const text = question.text;
        let answer = "";
        const currentValue = text.value;

        if (!currentValue) {
          if (labelLower.includes('experience') || labelLower.includes('years')) {
            answer = profile.experience || "3";
          } else if (labelLower.includes('phone') || labelLower.includes('mobile')) {
            answer = phone;
          } else if (labelLower.includes('street')) {
            answer = profile.address || "";
          } else if (labelLower.includes('city') || labelLower.includes('location') || labelLower.includes('address')) {
            answer = location;
          } else if (labelLower.includes('signature') || labelLower.includes('legal name') || labelLower.includes('your name') || labelLower.includes('full name')) {
            answer = fullName;
          } else if (labelLower.includes('name')) {
            if (labelLower.includes('full')) {
              answer = fullName;
            } else if (labelLower.includes('first') && !labelLower.includes('last')) {
              answer = firstName;
            } else if (labelLower.includes('middle') && !labelLower.includes('last')) {
              answer = "";
            } else if (labelLower.includes('last') && !labelLower.includes('first')) {
              answer = lastName;
            } else {
              answer = fullName;
            }
          } else if (labelLower.includes('notice')) {
            answer = profile.noticePeriod || "2 weeks";
          } else if (labelLower.includes('salary') || labelLower.includes('compensation') || labelLower.includes('ctc') || labelLower.includes('pay')) {
            answer = profile.expectedSalary || "";
          } else if (labelLower.includes('linkedin')) {
            answer = linkedin;
          } else if (labelLower.includes('website') || labelLower.includes('blog') || labelLower.includes('portfolio') || labelLower.includes('link')) {
            answer = website;
          } else if (labelLower.includes('headline')) {
            answer = profile.headline || "";
          } else if (labelLower.includes('state') || labelLower.includes('province')) {
            answer = location.split(',').slice(-2)[0]?.trim() || "";
          } else if (labelLower.includes('zip') || labelLower.includes('postal') || labelLower.includes('code')) {
            answer = profile.zipcode || "";
          } else if (labelLower.includes('country')) {
            answer = location.split(',').pop().trim() || "";
          } else if (labelLower.includes('first name')) {
            answer = firstName;
          } else if (labelLower.includes('last name')) {
            answer = lastName;
          } else if (labelLower.includes('email')) {
            answer = email;
          } else {
            // Unknown question - skip (no AI fallback)
            console.log("[LJB EasyApply] Unknown question, skipping:", question.label);
          }

          if (answer) {
            dispatchInput(text, answer);
            console.log("[LJB EasyApply] Filled text:", answer, "for:", question.label);
          }
        }
        continue;
      }

      // Handle textarea questions
      if (question.textarea) {
        const textarea = question.textarea;
        if (!textarea.value) {
          // Unknown textarea question - skip (no AI fallback)
          console.log("[LJB EasyApply] Unknown textarea question, skipping:", question.label);
        }
        continue;
      }

      // Handle checkbox questions
      if (question.checkbox) {
        const checkbox = question.checkbox;
        const labelLower = question.label.toLowerCase();
        // Check boxes for terms, privacy policy, etc.
        if (labelLower.includes('terms') || labelLower.includes('privacy') || labelLower.includes('agree') || labelLower.includes('consent')) {
          if (!checkbox.checked) {
            checkbox.click();
            console.log("[LJB EasyApply] Checked checkbox for:", question.label);
          }
        } else {
          console.log("[LJB EasyApply] Unknown checkbox, skipping:", question.label);
        }
        continue;
      }
    }
  }

  async function getAIFallback(question, profile, summary) {
    if (typeof LJBAIHelper === 'undefined') {
      console.log("[LJB EasyApply] AI helper not available, using empty fallback");
      return "";
    }

    try {
      const prompt = `You are filling out a job application form. Answer the following question concisely based on the user's profile.
      
Question: ${question}

User Profile:
- Name: ${profile.fullName || ""}
- Email: ${profile.email || ""}
- Phone: ${profile.phone || ""}
- Location: ${profile.location || ""}
- Summary: ${summary || ""}

Provide a concise answer (under 350 characters). If the question asks for years of experience, provide a number. If yes/no, provide Yes or No.`;

      console.log("[LJB EasyApply] Using AI fallback for question:", question);
      const result = await LJBAIHelper.fillFormWithAI([{ label: question, type: "text" }], null, {}, profile);
      return result && result[question] ? result[question] : "";
    } catch (error) {
      console.error("[LJB EasyApply] AI fallback failed:", error);
      return "";
    }
  }

  function findButtonByText(texts) {
    const buttons = Array.from(document.querySelectorAll("button, [role='button']"));
    for (const button of buttons) {
      const label = (button.innerText || button.textContent || button.getAttribute("aria-label") || "").toLowerCase();
      if (texts.some((text) => label.includes(text.toLowerCase())) && !button.disabled) {
        return button;
      }
    }
    return null;
  }

  function findApplyModal() {
    // Comprehensive selectors to catch all modal variations
    const selectors = [
      // Primary Easy Apply selectors
      ".jobs-easy-apply-modal",
      ".jobs-easy-apply-modal__content",
      ".jobs-apply-form",
      // Artdeco modal selectors
      ".artdeco-modal",
      ".artdeco-modal__content",
      ".artdeco-modal__container",
      ".artdeco-modal-overlay",
      // Role-based selectors
      "[role='dialog']",
      "[role='modal']",
      // Generic dialog/selectors
      ".jobs-modal",
      ".jobs-modal-content",
      ".apply-modal",
      ".easy-apply-modal",
      // LinkedIn specific
      ".scaffold-modal",
      ".scaffold-modal__content",
      "div[data-test-modal-container]",
      "div[data-test-easy-apply-modal]",
      // XPath-style queries for common patterns
      "div[class*='modal']",
      "div[class*='apply']",
      // Generic overlay containers
      ".artdeco-modal-overlay__content"
    ];
    
    // Try each selector
    for (const selector of selectors) {
      try {
        const elements = document.querySelectorAll(selector);
        for (const el of elements) {
          // Check if this element is visible and contains form-like content
          const rect = el.getBoundingClientRect();
          const isVisible = rect.width > 100 && rect.height > 100 && rect.top >= 0;
          const hasContent = el.innerText && el.innerText.length > 50;
          
          if (isVisible && hasContent) {
            console.log("[LJB Easy Apply] Found modal using selector:", selector);
            console.log("[LJB Easy Apply] Modal class:", el.className?.substring(0, 100));
            return el;
          }
        }
      } catch (e) {
        // Invalid selector, skip
      }
    }
    
    // Debug: Log what elements we did find
    console.log("[LJB Easy Apply] No modal found. Checking for any dialog-like elements...");
    const allDialogs = document.querySelectorAll("[role='dialog'], .artdeco-modal, .jobs-easy-apply-modal");
    console.log("[LJB Easy Apply] Dialog elements in DOM:", allDialogs.length);
    allDialogs.forEach((d, i) => {
      const rect = d.getBoundingClientRect();
      console.log(`[LJB Easy Apply] Dialog ${i}:`, { 
        class: d.className?.substring(0, 50), 
        visible: d.offsetParent !== null,
        width: rect.width, 
        height: rect.height 
      });
    });
    
    return null;
  }

  async function waitForModal(maxWaitMs = 10000) {
    const start = Date.now();
    console.log("[LJB Easy Apply] Waiting up to", maxWaitMs, "ms for modal...");
    while (Date.now() - start < maxWaitMs) {
      const modal = findApplyModal();
      if (modal) {
        // Check if modal has any input fields (more lenient check)
        const hasFormContent = modal.querySelector('input, select, textarea');
        console.log("[LJB Easy Apply] Modal found! Checking for form content...");
        
        if (hasFormContent) {
          console.log("[LJB Easy Apply] Modal detected with form inputs");
          return true;
        }
        
        // Also accept modal if it has substantial content (over 100 chars)
        if (modal.innerText && modal.innerText.length > 100) {
          console.log("[LJB Easy Apply] Modal detected with content (no inputs yet)");
          return true;
        }
        
        console.log("[LJB Easy Apply] Modal found but minimal content, waiting...");
      }
      await delay(500);
    }
    console.log("[LJB Easy Apply] Modal not detected after", maxWaitMs, "ms");
    
    // Final debug: dump body HTML to see what's on the page
    console.log("[LJB Easy Apply] DEBUG: Looking for any modal-like elements...");
    const body = document.body;
    if (body) {
      const allModals = body.querySelectorAll('*[class*="modal"], *[class*="dialog"], *[role="dialog"]');
      console.log("[LJB Easy Apply] DEBUG: Elements with modal/dialog in class name:", allModals.length);
      allModals.forEach((el, i) => {
        console.log(`[LJB Easy Apply] DEBUG: Element ${i}:`, el.className?.substring(0, 80));
      });
    }
    
    return false;
  }

  async function submitEasyApply(profile, jobDetails = {}, resumeAttachment = null) {
    const settings = await LJBStorage.getSettings();
    const preferences = settings.preferences || {};
    const rateLimit = (preferences.easyApplyRateLimit || 10) * 1000;

    // Wait for modal to appear
    const modalReady = await waitForModal(5000);
    if (!modalReady) {
      console.log("[LJB Easy Apply] Modal didn't appear, checking if form exists in document...");
      // Check if there are any form elements visible on the page
      const anyForm = document.querySelector('input, select, textarea, [role="dialog"]');
      if (anyForm) {
        console.log("[LJB Easy Apply] Found form elements, proceeding anyway");
      } else {
        console.log("[LJB Easy Apply] No form elements found on page");
        return false;
      }
    }

    for (let step = 0; step < 6; step += 1) {
      await delay(1500);
      
      // Always use standard label-based form fill (no AI)
      console.log("[LJB Easy Apply] Using standard form fill (label-based) - step", step);
      await fillForm(profile);

      const nextButton = findButtonByText(["next", "review", "continue"]);
      if (nextButton) {
        console.log("[LJB Easy Apply] Clicking next/review button");
        nextButton.click();
        await delay(2000);
        continue;
      }
      const submitButton = findButtonByText(["submit application", "submit"]);
      if (submitButton) {
        console.log("[LJB Easy Apply] Clicking submit button");
        submitButton.click();
        await delay(2000);
        console.log("[LJB Easy Apply] Application submitted!");
        await delay(rateLimit);
        return true;
      }
      
      console.log("[LJB Easy Apply] No next/submit button found, form filling complete for this step");
      break;
    }
    console.log("[LJB Easy Apply] Form submission loop ended without finding submit button");
    return false;
  }

  async function applyToJob(postUrl, profile, jobDetails = {}, resumeAttachment = null) {
    const current = window.location.href;
    if (!current.includes("/jobs/view/") && !current.includes("/feed/update/")) {
      // Store pending data and verify before redirecting
      const pendingData = { postUrl, profile, jobDetails, resumeAttachment, timestamp: Date.now() };
      console.log("[LJB Easy Apply] Storing pending data before redirect:", pendingData);
      await chrome.storage.local.set({ ljb_pendingApply: pendingData });
      // Verify storage worked
      const verify = await chrome.storage.local.get(["ljb_pendingApply"]);
      if (!verify.ljb_pendingApply) {
        console.error("[LJB Easy Apply] FAILED to store pending data!");
      } else {
        console.log("[LJB Easy Apply] Pending data stored successfully");
      }
      // Try to preserve search context by copying URL parameters
      try {
        const currentUrl = new URL(current);
        const targetUrl = new URL(postUrl);
        // Remove language-related parameters from target URL first
        targetUrl.searchParams.delete('lang');
        targetUrl.searchParams.delete('locale');
        targetUrl.searchParams.delete('language');
        targetUrl.searchParams.delete('lc');
        // Set English language
        targetUrl.searchParams.set('lang', 'en');
        // Copy non-language parameters from current URL to target URL
        currentUrl.searchParams.forEach((value, key) => {
          if (!['lang', 'locale', 'language', 'lc'].includes(key.toLowerCase())) {
            targetUrl.searchParams.set(key, value);
          }
        });
        // Set cookie to force English
        document.cookie = "li_lang=en_US; path=/; domain=.linkedin.com";
        window.location.href = targetUrl.toString();
      } catch (e) {
        document.cookie = "li_lang=en_US; path=/; domain=.linkedin.com";
        window.location.href = postUrl + (postUrl.includes('?') ? '&' : '?') + 'lang=en';
      }
      return { success: false, method: "redirect" };
    }

    // Check if modal is already open (form might be visible)
    const existingModal = findApplyModal();
    if (existingModal) {
      console.log("[LJB Easy Apply] Modal already open, proceeding directly to submit");
      const success = await submitEasyApply(profile, jobDetails, resumeAttachment);
      return { success, method: "easy_apply" };
    }

    // Try multiple selectors for Easy Apply button
    const easyApplyButton = findButtonByText(["easy apply"]) ||
      document.querySelector(".jobs-apply-button--top-card") ||
      document.querySelector("[data-test-id='apply-button']") ||
      document.querySelector(".artdeco-button--primary");
    
    if (easyApplyButton) {
      console.log("[LJB Easy Apply] Found Easy Apply button");
      easyApplyButton.scrollIntoView({ block: "center" });
      await delay(500);
      easyApplyButton.click();
      console.log("[LJB Easy Apply] Clicked Easy Apply button, waiting for modal...");
      
      // Wait for modal to appear (up to 10 seconds)
      const modalReady = await waitForModal(10000);
      if (!modalReady) {
        console.log("[LJB Easy Apply] Modal didn't appear after clicking, aborting");
        return { success: false, method: "modal_timeout" };
      }
      
      console.log("[LJB Easy Apply] Modal detected, proceeding to submit");
      const success = await submitEasyApply(profile, jobDetails, resumeAttachment);
      return { success, method: "easy_apply" };
    }

    console.log("[LJB Easy Apply] No Easy Apply button found and no modal open, trying direct submit");
    const success = await submitEasyApply(profile, jobDetails, resumeAttachment);
    return { success, method: success ? "easy_apply" : "no_easy_apply" };
  }

  async function attemptPendingApply() {
    console.log("[LJB Easy Apply] attemptPendingApply called, isApplying:", isApplying);
    if (isApplying) {
      console.log("[LJB Easy Apply] Already applying, skipping");
      return;
    }
    
    const data = await new Promise((resolve) => chrome.storage.local.get(["ljb_pendingApply", "ljb_autoApplyQueue", "ljb_autoApplyIndex"], resolve));
    console.log("[LJB Easy Apply] Raw storage data:", data);
    const pending = data.ljb_pendingApply;
    console.log("[LJB Easy Apply] Pending apply data:", pending);
    if (!pending) {
      console.log("[LJB Easy Apply] No pending apply found - keys in storage:", Object.keys(data));
      return;
    }
    
    isApplying = true;
    // Extract job ID from both URLs for comparison (more reliable than full URL)
    const currentJobId = window.location.href.match(/\/jobs\/view\/(\d+)/)?.[1];
    const pendingJobId = pending.postUrl.match(/\/jobs\/view\/(\d+)/)?.[1];
    console.log("[LJB Easy Apply] Current job ID:", currentJobId, "Pending job ID:", pendingJobId);
    if (currentJobId && pendingJobId && currentJobId !== pendingJobId) {
      console.log("[LJB Easy Apply] Job ID mismatch:", currentJobId, "vs", pendingJobId);
      return;
    }
    console.log("[LJB Easy Apply] Job ID match, proceeding with apply");
    const result = await applyToJob(pending.postUrl, pending.profile, pending.jobDetails, pending.resumeAttachment);
    if (result.success) {
      console.log("[LJB Easy Apply] Application successful, removing pending data");
      await chrome.storage.local.remove(["ljb_pendingApply"]);
      chrome.runtime.sendMessage({ type: "APPLIED", postUrl: pending.postUrl, role: "Easy Apply", mode: "easy_apply_only" });
      await LJBStorage.addSeenPost(pending.postUrl);
      await LJBStorage.addAppliedJob(pending.postUrl);
    } else {
      console.log("[LJB Easy Apply] Application failed or incomplete, keeping pending data for retry");
    }
    isApplying = false;

    // Handle auto-apply queue
    const queue = data.ljb_autoApplyQueue;
    let index = data.ljb_autoApplyIndex || 0;
    if (queue && index < queue.length - 1) {
      // Move to next job
      index++;
      await chrome.storage.local.set({ ljb_autoApplyIndex: index });
      const nextJob = queue[index];
      await chrome.storage.local.set({ ljb_pendingApply: { postUrl: nextJob.jobUrl, profile: pending.profile, jobDetails: nextJob, resumeAttachment: pending.resumeAttachment, timestamp: Date.now() } });
      window.location.href = nextJob.jobUrl;
    } else if (queue) {
      // Queue completed
      await chrome.storage.local.remove(["ljb_autoApplyQueue", "ljb_autoApplyIndex"]);
      alert("Auto-apply flow completed!");
    }
  }

  window.LJB = window.LJB || {};
  window.LJB.applyToJob = applyToJob;

  function initEasyApply() {
    attemptPendingApply();
  }

  // Listen for URL changes (LinkedIn SPA navigation)
  let lastUrl = window.location.href;
  const urlObserver = new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      console.log("[LJB Easy Apply] URL changed to:", currentUrl);
      attemptPendingApply();
    }
  });
  urlObserver.observe(document.body, { subtree: true, childList: true });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initEasyApply);
  } else {
    initEasyApply();
  }
})();

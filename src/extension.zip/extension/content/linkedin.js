(function () {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "SCAN_PAGE") {
      if (window.feedScraper && typeof window.feedScraper.scanFeed === "function") {
        window.feedScraper.scanFeed().then(() => sendResponse({ success: true }));
        return true;
      }
    }
  });

  function initLinkedIn() {
    chrome.storage.local.get(["ljb_pendingApply"], async ({ ljb_pendingApply }) => {
      if (!ljb_pendingApply) return;
      if (!window.location.href.includes(ljb_pendingApply.postUrl)) return;
      try {
        await window.LJB.applyToJob(ljb_pendingApply.postUrl, ljb_pendingApply.profile);
      } catch (error) {
        console.error("Pending apply failed", error);
      }
      chrome.storage.local.remove(["ljb_pendingApply"]);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initLinkedIn);
  } else {
    initLinkedIn();
  }
})();

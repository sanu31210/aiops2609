(function () {
  let isScanning = false;

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function normalize(value) {
    return (value || "")
      .toLowerCase()
      .replace(/[\u2010-\u2015–—‑]/g, " ")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  function normalizeCompact(value) {
    return normalize(value).replace(/\s+/g, "");
  }

  // Find feed cards by structure analysis (works with dynamic class names)
  function findFeedCards() {
    function isVisibleElement(el) {
      if (!el) return false;
      const hidden = el.className?.includes("visually-hidden") || el.getAttribute("aria-hidden") === "true" || el.hasAttribute("hidden");
      if (hidden) return false;
      const style = window.getComputedStyle(el);
      if (style.visibility === "hidden" || style.display === "none" || style.opacity === "0") return false;
      const rect = el.getBoundingClientRect();
      return el.offsetParent !== null && rect.width > 10 && rect.height > 10;
    }

    function findVisibleSelector(selectors) {
      const elements = Array.from(document.querySelectorAll(selectors));
      return elements.find(isVisibleElement);
    }

    let main = findVisibleSelector("[role='main']");
    if (!main) main = findVisibleSelector(".scaffold-finite-scroll__content");
    if (!main) main = findVisibleSelector(".search-results-container, .search-results__list, .scaffold-layout__main, .scaffold-layout__content, main, [role='region']");
    if (!main) {
      console.log("[LJB] No visible feed container found; using document fallback");
      main = document;
    }

    console.log("[LJB] Main container found:", main.className || main.tagName);

    // Content-based detection: find elements with substantial text + emails + links
    const emailRegex = /([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/gi;
    const allDivs = Array.from(main.querySelectorAll("div, article, section, li"));
    
    const cards = allDivs.filter(el => {
      if (!isVisibleElement(el)) return false;
      
      const text = el.innerText || "";
      const hasSubstantialText = text.length > 100;
      const hasEmail = emailRegex.test(text);
      const hasLink = el.querySelector("a[href]") !== null;
      const hasButton = el.querySelector("button") !== null;
      
      return hasSubstantialText && hasEmail && (hasLink || hasButton);
    });

    console.log("[LJB] Content-based cards found:", cards.length);

    
    // Deduplicate: keep smallest cards (most specific), discard nested larger containers
    const sorted = cards.sort((a, b) => {
      const textA = a.innerText?.length || 0;
      const textB = b.innerText?.length || 0;
      return textA - textB;  // Sort smallest first
    });
    
    const seen = new Set();
    const filtered = sorted.filter(card => {
      for (const existing of seen) {
        if (existing.contains(card) || card.contains(existing)) {
          // If this card contains an already-seen card, skip it (it's the outer container)
          return false;
        }
      }
      seen.add(card);
      return true;
    }).slice(0, 50);

    console.log("[LJB] Deduplicated cards:", filtered.length);
    return filtered;
  }

  function getPostText(card) {
    // Get all visible text from the feed post
    let text = card.innerText || "";
    
    // For feed posts, extract main content areas
    const textContainers = card.querySelectorAll(
      "[dir='ltr'], " +
      ".feed-shared-text__text-view, " +
      ".feed-shared-update-v2__description, " +
      "p, " +
      ".base-card__summary, " +
      "span[data-test-id*='text']"
    );
    
    if (textContainers.length > 0) {
      const texts = Array.from(textContainers)
        .map(el => el.innerText || "")
        .filter(t => t.length > 10)
        .join(" ");
      if (texts.length > 0) {
        text = texts;
      }
    }
    
    return text.trim().slice(0, 500); // Limit to 500 chars for matching
  }

  function hasEasyApply(card) {
    // Check all footer items in the card for Easy Apply
    const footerItems = card.querySelectorAll(".job-card-container__footer-item, li[class*='footer']");
    for (const item of footerItems) {
      const footerText = (item.innerText || "").toLowerCase();
      if (footerText === "easy apply" || footerText.indexOf("easy apply") !== -1) {
        return true;
      }
    }

    // Look for apply buttons with various selectors
    const applyButton = card.querySelector(
      "button[aria-label*='Easy Apply'], button[aria-label*='Apply'], " +
      "button[data-control-name*='easy_apply'], button[data-test-id*='apply'], " +
      ".jobs-apply-button, a[href*='apply']"
    );
    return Boolean(applyButton);
  }

    function getPostUrl(card) {
    const urn =
      card.getAttribute("data-urn") ||
      card.dataset.urn ||
      card.dataset.entityUrn ||
      card.dataset.activityUrn ||
      card.querySelector("[data-urn]")?.getAttribute("data-urn") ||
      card.querySelector("[data-entity-urn]")?.getAttribute("data-entity-urn") ||
      card.querySelector("[data-activity-urn]")?.getAttribute("data-activity-urn");

    if (urn) {
      const cleaned = urn.replace(/^urn:li:/, "");
      return `https://www.linkedin.com/feed/update/${cleaned}`;
    }

    const postLink = card.querySelector(
      "a[href*='/feed/update/'], " +
      "a[href*='/posts/'], " +
      "a[href*='/pulse/'], " +
      "a[href*='/articles/'], " +
      "a[href*='/feed/'], " +
      "a[href*='linkedin.com/feed/update/'], " +
      "a[href*='linkedin.com/posts/']"
    );

    if (postLink?.href) {
      return postLink.href.split("?")[0];
    }

    // Fallback: Generate unique URL from post content hash
    const text = (card.innerText || "").substring(0, 150);
    // Remove non-ASCII characters and encode safely
    const sanitized = text.replace(/[^\x00-\x7F]/g, "").substring(0, 50);
    try {
      const hash = btoa(sanitized || "fallback").substring(0, 16);
      return `https://www.linkedin.com/feed/content-search/${hash}`;
    } catch (e) {
      // Final fallback: use timestamp-based ID
      return `https://www.linkedin.com/feed/content-search/post-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }
  }

  function streamMatches(text, preferences) {
    const normalized = normalize(text);
    const compact = normalizeCompact(text);

    const keywordMatch = preferences.keywords.some((keyword) => {
      const normKeyword = normalize(keyword);
      const compactKeyword = normalizeCompact(keyword);
      return normalized.includes(normKeyword) || compact.includes(compactKeyword);
    });

    const roleMatch = preferences.roles.some((role) => {
      const normRole = normalize(role);
      const compactRole = normalizeCompact(role);
      return normalized.includes(normRole) || compact.includes(compactRole);
    });

    return keywordMatch || roleMatch;
  }

  function extractEmail(text) {
    if (!text) return [];
    // Match email addresses - return all matches
    const emailRegex = /([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/gi;
    const matches = text.match(emailRegex);
    // Remove duplicates
    return matches ? Array.from(new Set(matches)) : [];
  }

  function extractEmailFromCard(card) {
    // Search full card text first
    const fullText = card.innerText || "";
    let emails = extractEmail(fullText);
    if (emails.length > 0) return emails;
    
    // Fallback: search in links and visible elements
    const links = card.querySelectorAll("a");
    for (const link of links) {
      const linkText = link.innerText || link.href || "";
      const extracted = extractEmail(linkText);
      emails = emails.concat(extracted);
    }
    
    return Array.from(new Set(emails)); // Remove duplicates
  }

  function queueAutoDraft(match, profile) {
    if (!profile || !profile.email || !Array.isArray(match.recruiterEmails) || match.recruiterEmails.length === 0) {
      return;
    }

    chrome.runtime.sendMessage({
      type: "SEND_EMAIL",
      recruiterEmail: match.recruiterEmails.join(","),
      role: "email",
      profile,
      postUrl: match.postUrl
    });
  }

  function isUnwantedUrl(url) {
    if (!url) return true;
    const urlLower = url.toLowerCase();
    return (
      urlLower.includes("/in/") ||              // Profile links
      urlLower.includes("/news/") ||            // News articles
      urlLower.includes("/premium/") ||         // Premium/product pages
      urlLower.includes("/games/") ||           // Games/patch promotional cards
      urlLower.includes("/about.linkedin") ||   // About/ads
      (urlLower.includes("/company/") && !urlLower.includes("/jobs/")) // Company pages (not jobs)
    );
  }

  async function scanFeed(autoCreateDrafts = false) {
    if (isScanning) {
      console.log("[LJB] scanFeed already running, skipping");
      return;
    }
    isScanning = true;
    console.log("[LJB] scanFeed started");
    console.log("[LJB] Current URL:", window.location.href);
    
    const settings = await LJBStorage.getSettings();
    const preferences = settings.preferences;
    const seenPosts = await LJBStorage.getSeenPosts();
    
    // Find feed cards using structure analysis
    const cards = findFeedCards();
    console.log("[LJB] feed cards found:", cards.length);

    cards.forEach((card, index) => {
      const preview = getPostText(card).slice(0, 140);
      const url = getPostUrl(card) || "<no-url>";
      const urn = card.getAttribute("data-urn") || card.dataset.urn || card.querySelector("[data-urn]")?.getAttribute("data-urn") || "<no-urn>";
      console.log("[LJB] card", index, { url, urn, preview, easyApply: hasEasyApply(card), emails: extractEmailFromCard(card) });
    });

    const matches = [];

    for (const card of cards) {
      const postUrl = getPostUrl(card);
      if (!postUrl || isUnwantedUrl(postUrl)) {
        continue;
      }
      
      if (seenPosts.includes(postUrl)) {
        continue;
      }
      
      const text = getPostText(card);
      if (!text) {
        continue;
      }
      
      if (!streamMatches(text, preferences)) {
        continue;
      }

      matches.push({
        postUrl,
        preview: text.slice(0, 140),
        easyApply: hasEasyApply(card),
        recruiterEmails: extractEmailFromCard(card),
        rawText: text
      });
    }

    if (matches.length) {
      console.log("[LJB] matching posts found", matches.length, matches.map((item) => item.postUrl));
      chrome.runtime.sendMessage({ type: "POSTS_FOUND", count: matches.length });
    } else {
      console.log("[LJB] no matching posts found");
    }

    if (window.ljbSidebar && typeof window.ljbSidebar.updateMatches === "function") {
      window.ljbSidebar.updateMatches(matches);
    }

    if (autoCreateDrafts && matches.length > 0) {
      const settings = await LJBStorage.getSettings();
      const profile = settings.profile || {};
      matches.forEach((match) => queueAutoDraft(match, profile));
    }

    isScanning = false;
  }

  function observeFeed() {
    function isVisibleElement(el) {
      if (!el) return false;
      const hidden = el.className?.includes("visually-hidden") || el.getAttribute("aria-hidden") === "true" || el.hasAttribute("hidden");
      if (hidden) return false;
      const style = window.getComputedStyle(el);
      if (style.visibility === "hidden" || style.display === "none" || style.opacity === "0") return false;
      const rect = el.getBoundingClientRect();
      return el.offsetParent !== null && rect.width > 10 && rect.height > 10;
    }

    function findVisibleSelector(selectors) {
      const elements = Array.from(document.querySelectorAll(selectors));
      return elements.find(isVisibleElement);
    }

    let root = findVisibleSelector("[role='main']");

    if (!root) {
      root = findVisibleSelector(
        ".scaffold-finite-scroll__content"
      );
    }

    if (!root) {
      root = findVisibleSelector(
        ".search-results-container, " +
        ".search-results__list, " +
        ".scaffold-layout__main, " +
        ".scaffold-layout__content, " +
        "main"
      );
    }

    if (!root) {
      console.log("[LJB] Could not find visible feed container for observation, using document");
      root = document;
    }

    console.log("[LJB] Starting feed observation on feed container");

    const observer = new MutationObserver(async () => {
      await delay(2000); // Wait for new posts to fully load
      scanFeed();
    });
    
    observer.observe(root, { childList: true, subtree: true });
  }

  async function autoScroll(count = 2) {
    const scrollable = document.scrollingElement || document.documentElement;
    for (let i = 0; i < count; i += 1) {
      scrollable.scrollBy({ top: 1200, behavior: "smooth" });
      await delay(1800);
    }
  }

  async function autoScanFeed(count = 5) {
    console.log("[LJB] autoScanFeed starting with scroll count:", count);
    await autoScroll(count);
    await delay(1500);
    await scanFeed(true);
  }

  window.feedScraper = { scanFeed, autoScanFeed };

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "SCAN_PAGE") {
      scanFeed().then(() => sendResponse({ scanned: true }));
      return true;
    }
    if (message.type === "AUTO_SCAN_PAGE") {
      LJBStorage.getSettings().then((settings) => {
        const scrollCount = Number(settings.preferences.autoScrollCount || 5);
        autoScanFeed(scrollCount).then(() => sendResponse({ scanned: true }));
      });
      return true;
    }
  });

  function initFeedScraper() {
    scanFeed();
    observeFeed();
    autoScroll();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initFeedScraper);
  } else {
    initFeedScraper();
  }
})();

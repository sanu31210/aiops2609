const LJBStorage = {
  getSync(keys) {
    return new Promise((resolve) => chrome.storage.sync.get(keys, resolve));
  },

  setSync(items) {
    return new Promise((resolve) => chrome.storage.sync.set(items, resolve));
  },

  getLocal(keys) {
    return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  },

  setLocal(items) {
    return new Promise((resolve) => chrome.storage.local.set(items, resolve));
  },

  async getSettings() {
    const defaults = {
      profile: {
        fullName: "",
        email: "",
        phone: "",
        resumeUrl: "",
        linkedinUrl: "",
        summary: "",
        website: "",
        location: "",
        experience: "3",
        address: "",
        noticePeriod: "2 weeks",
        expectedSalary: "",
        headline: "",
        zipcode: ""
      },
      preferences: {
        roles: ["project manager", "business analyst", "scrum master"],
        keywords: ["hiring", "we are hiring", "looking for", "urgent requirement"],
        dateFilter: "past-24h",
        autoScrollCount: 5,
        autoApply: false,
        emailFallback: true,
        runInterval: 30,
        easyApplyOnlyMode: false,
        easyApplyRateLimit: 10
      },
      stats: {
        totalApplied: 0,
        totalEmailed: 0,
        lastRunAt: null
      }
    };
    const stored = await this.getSync(defaults);
    return {
      profile: Object.assign({}, defaults.profile, stored.profile),
      preferences: Object.assign({}, defaults.preferences, stored.preferences),
      stats: Object.assign({}, defaults.stats, stored.stats),
      templates: Object.assign({}, stored.templates || {})
    };
  },

  async getSeenPosts() {
    const { seenPosts = [] } = await this.getLocal({ seenPosts: [] });
    return seenPosts;
  },

  async addSeenPost(postUrl) {
    const seenPosts = await this.getSeenPosts();
    if (!seenPosts.includes(postUrl)) {
      seenPosts.push(postUrl);
      await this.setLocal({ seenPosts });
    }
  },

  async getEmailedRecruiters() {
    const { emailedRecruiters = [] } = await this.getLocal({ emailedRecruiters: [] });
    return emailedRecruiters;
  },

  async addEmailedRecruiter(email) {
    const emailedRecruiters = await this.getEmailedRecruiters();
    if (!emailedRecruiters.includes(email)) {
      emailedRecruiters.push(email);
      await this.setLocal({ emailedRecruiters });
    }
  },

  async getAppliedJobs() {
    const { appliedJobs = [] } = await this.getLocal({ appliedJobs: [] });
    return appliedJobs;
  },

  async addAppliedJob(jobUrl) {
    const appliedJobs = await this.getAppliedJobs();
    if (!appliedJobs.includes(jobUrl)) {
      appliedJobs.push(jobUrl);
      await this.setLocal({ appliedJobs });
    }
  },

  async getAIConfig() {
    const { aiApiKey } = await this.getSync({ aiApiKey: "" });
    return { apiKey: aiApiKey };
  }
};

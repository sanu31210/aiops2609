// Owner-provided default API key (Hugging Face)
// Users can override this in Options → Easy Apply Only Mode → Codeium API Key
const DEFAULT_AI_API_KEY = "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";

const LJBAIHelper = {
  async getAIConfig() {
    const { aiApiKey } = await LJBStorage.getSync({ aiApiKey: "" });
    // Use user-provided key if available, otherwise fall back to default
    const apiKey = aiApiKey || DEFAULT_AI_API_KEY;
    
    // Warn if default key hasn't been replaced
    if (!aiApiKey && DEFAULT_AI_API_KEY === "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") {
      console.warn("[LJB AI] Default API key not configured. Please replace YOUR_HUGGING_FACE_API_KEY_HERE in ai_helper.js or provide a key in Options.");
    }
    
    return { apiKey };
  },

  async fillFormWithAI(formFields, resume, jobDetails, profile) {
    const { apiKey } = await this.getAIConfig();
    if (!apiKey) {
      console.log("[LJB AI] No API key configured, using fallback");
      return null;
    }

    try {
      const prompt = this.buildFormFillPrompt(formFields, resume, jobDetails, profile);
      const response = await this.callAI(prompt);
      return this.parseFormResponse(response, formFields);
    } catch (error) {
      console.error("[LJB AI] Form filling error:", error);
      return null;
    }
  },

  async generateCoverLetter(jobDetails, resume, profile) {
    const { apiKey } = await this.getAIConfig();
    if (!apiKey) {
      console.log("[LJB AI] No API key configured, using template fallback");
      return LJBTemplates.getTemplate(jobDetails.role || "business analyst", profile);
    }

    try {
      const prompt = this.buildCoverLetterPrompt(jobDetails, resume, profile);
      const response = await this.callAI(prompt);
      return this.parseCoverLetterResponse(response);
    } catch (error) {
      console.error("[LJB AI] Cover letter generation error:", error);
      return LJBTemplates.getTemplate(jobDetails.role || "business analyst", profile);
    }
  },

  async answerScreeningQuestion(question, resume, jobDetails, profile) {
    const { apiKey } = await this.getAIConfig();
    if (!apiKey) {
      console.log("[LJB AI] No API key configured, returning null");
      return null;
    }

    try {
      const prompt = this.buildScreeningQuestionPrompt(question, resume, jobDetails, profile);
      const response = await this.callAI(prompt);
      return response.trim();
    } catch (error) {
      console.error("[LJB AI] Screening question answer error:", error);
      return null;
    }
  },

  async generateUserQuestions(jobDetails, resume, profile) {
    const { apiKey } = await this.getAIConfig();
    if (!apiKey) {
      return [];
    }

    try {
      const prompt = this.buildUserQuestionsPrompt(jobDetails, resume, profile);
      const response = await this.callAI(prompt);
      return this.parseQuestionsResponse(response);
    } catch (error) {
      console.error("[LJB AI] User questions generation error:", error);
      return [];
    }
  },

  buildFormFillPrompt(formFields, resume, jobDetails, profile) {
    return `You are helping fill out a job application form.
    
User Profile:
- Name: ${profile.fullName || "Not provided"}
- Email: ${profile.email || "Not provided"}
- Phone: ${profile.phone || "Not provided"}
- LinkedIn: ${profile.linkedinUrl || "Not provided"}
- Summary: ${profile.summary || "Not provided"}

Job Details:
- Title: ${jobDetails.title || "Not provided"}
- Company: ${jobDetails.company || "Not provided"}
- Location: ${jobDetails.location || "Not provided"}

Resume: ${resume ? "Attached" : "Not provided"}

Form Fields to Fill:
${formFields.map(f => `- ${f.label}: ${f.type || "text"}`).join("\n")}

Provide the filled values in JSON format with field labels as keys and filled values as values. Only return valid JSON, no other text.`;
  },

  buildCoverLetterPrompt(jobDetails, resume, profile) {
    return `Generate a professional cover letter for a job application.

User Profile:
- Name: ${profile.fullName || "Not provided"}
- Email: ${profile.email || "Not provided"}
- Phone: ${profile.phone || "Not provided"}
- LinkedIn: ${profile.linkedinUrl || "Not provided"}
- Summary: ${profile.summary || "Not provided"}

Job Details:
- Title: ${jobDetails.title || "Not provided"}
- Company: ${jobDetails.company || "Not provided"}
- Location: ${jobDetails.location || "Not provided"}
- Description: ${jobDetails.description || "Not provided"}

Resume: ${resume ? "Attached" : "Not provided"}

Generate a concise, professional cover letter (under 300 words). Return in JSON format with "subject" and "body" keys. Only return valid JSON, no other text.`;
  },

  buildScreeningQuestionPrompt(question, resume, jobDetails, profile) {
    return `Answer this job application screening question professionally and concisely.

Question: ${question}

User Profile:
- Name: ${profile.fullName || "Not provided"}
- Email: ${profile.email || "Not provided"}
- Phone: ${profile.phone || "Not provided"}
- Summary: ${profile.summary || "Not provided"}

Job Details:
- Title: ${jobDetails.title || "Not provided"}
- Company: ${jobDetails.company || "Not provided"}

Resume: ${resume ? "Attached" : "Not provided"}

Provide a professional answer. Keep it concise (under 150 words).`;
  },

  buildUserQuestionsPrompt(jobDetails, resume, profile) {
    return `Generate 3-5 clarifying questions a user should answer to improve their job application.

User Profile:
- Name: ${profile.fullName || "Not provided"}
- Summary: ${profile.summary || "Not provided"}

Job Details:
- Title: ${jobDetails.title || "Not provided"}
- Company: ${jobDetails.company || "Not provided"}
- Description: ${jobDetails.description || "Not provided"}

Resume: ${resume ? "Attached" : "Not provided"}

Generate questions that would help customize the application. Return as a JSON array of question strings. Only return valid JSON, no other text.`;
  },

  async callAI(prompt) {
    const { apiKey } = await this.getAIConfig();
    
    // Using Hugging Face Inference API as a free option
    // Users can configure their own endpoint if needed
    const endpoint = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2";
    
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          max_new_tokens: 500,
          temperature: 0.7,
          return_full_text: false
        }
      })
    });

    if (!response.ok) {
      throw new Error(`AI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    if (Array.isArray(data) && data[0]?.generated_text) {
      return data[0].generated_text;
    }
    throw new Error("Unexpected AI response format");
  },

  parseFormResponse(response, formFields) {
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) return null;
      const parsed = JSON.parse(jsonMatch[0]);
      return parsed;
    } catch (error) {
      console.error("[LJB AI] Failed to parse form response:", error);
      return null;
    }
  },

  parseCoverLetterResponse(response) {
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        return { subject: "Application for Position", body: response };
      }
      const parsed = JSON.parse(jsonMatch[0]);
      return { subject: parsed.subject || "Application for Position", body: parsed.body || response };
    } catch (error) {
      console.error("[LJB AI] Failed to parse cover letter response:", error);
      return { subject: "Application for Position", body: response };
    }
  },

  parseQuestionsResponse(response) {
    try {
      const jsonMatch = response.match(/\[[\s\S]*\]/);
      if (!jsonMatch) return [];
      const parsed = JSON.parse(jsonMatch[0]);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.error("[LJB AI] Failed to parse questions response:", error);
      return [];
    }
  }
};

const LJBTemplates = {
  defaultTemplates: {
    "project manager": {
      subject: "Experienced Project Manager interested in your opening",
      body: "Hello {name},\n\nI came across your hiring post and I would love to bring my experience as a Project Manager to your team. My name is {fullName}, and I have a proven record in driving complex programs, leading stakeholder alignment, and delivering on time.\n\nPlease let me know if you'd like to connect and review my resume.\n\nThanks,\n{fullName}\n{email}\n{phone}"
    },
    "business analyst": {
      subject: "Business Analyst available for your opening",
      body: "Hello {name},\n\nI saw your LinkedIn hiring post and wanted to introduce myself. I'm {fullName}, a Business Analyst with strong experience in requirements gathering, process optimization, and stakeholder collaboration.\n\nI would appreciate the chance to discuss how I can support your team.\n\nRegards,\n{fullName}\n{email}\n{phone}"
    },
    "scrum master": {
      subject: "Scrum Master ready to support your agile team",
      body: "Hi {name},\n\nMy name is {fullName}. I am an experienced Scrum Master who helps teams improve delivery, remove blockers, and establish effective agile practices. I saw your hiring post and would love to discuss the opportunity.\n\nThank you,\n{fullName}\n{email}\n{phone}"
    }
  },

  getTemplate(role, profile, overrides = {}) {
    const key = (role || "business analyst").toLowerCase();
    const template = overrides[key] || this.defaultTemplates[key] || this.defaultTemplates["business analyst"];
    const placeholders = {
      "{name}": profile.fullName.split(" ")[0] || "Hiring Manager",
      "{email}": profile.email,
      "{phone}": profile.phone,
      "{fullName}": profile.fullName,
      "{linkedinUrl}": profile.linkedinUrl
    };

    return {
      subject: Object.keys(placeholders).reduce((text, placeholder) => text.replace(new RegExp(placeholder, "g"), placeholders[placeholder] || ""), template.subject),
      body: Object.keys(placeholders).reduce((text, placeholder) => text.replace(new RegExp(placeholder, "g"), placeholders[placeholder] || ""), template.body)
    };
  }
};

async function getGmailToken(interactive = false) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, (token) => {
      if (chrome.runtime.lastError || !token) {
        reject(chrome.runtime.lastError || new Error("Unable to acquire Gmail auth token"));
        return;
      }
      resolve(token);
    });
  });
}

function buildRawEmail(from, to, bcc, subject, body, attachment) {
  const headers = [
    `From: ${from}`,
    `To: ${to}`,
    `Bcc: ${bcc}`,
    `Subject: ${subject}`
  ];

  if (attachment && attachment.data) {
    const boundary = "BOUNDARY_" + Math.random().toString(36).substring(2, 12);
    headers.push(`Content-Type: multipart/mixed; boundary="${boundary}"`);

    const messageParts = [];
    messageParts.push(`--${boundary}`);
    messageParts.push("Content-Type: text/plain; charset=UTF-8");
    messageParts.push("Content-Transfer-Encoding: 7bit");
    messageParts.push("");
    messageParts.push(body);
    messageParts.push(`--${boundary}`);
    messageParts.push(`Content-Type: ${attachment.type || "application/octet-stream"}; name="${attachment.name}"`);
    messageParts.push("Content-Transfer-Encoding: base64");
    messageParts.push(`Content-Disposition: attachment; filename="${attachment.name}"`);
    messageParts.push("");
    messageParts.push(attachment.data);
    messageParts.push(`--${boundary}--`);

    const raw = headers.join("\r\n") + "\r\n\r\n" + messageParts.join("\r\n");
    return btoa(unescape(encodeURIComponent(raw))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  headers.push("Content-Type: text/plain; charset=UTF-8");
  const raw = headers.join("\r\n") + "\r\n\r\n" + body;
  return btoa(unescape(encodeURIComponent(raw))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function createGmailDraft(from, to, bcc, subject, body, attachment) {
  console.log("[LJB] createGmailDraft", { from, to, bcc, subject, attachment: !!attachment });
  const token = await getGmailToken();
  const raw = buildRawEmail(from, to, bcc, subject, body, attachment);
  const response = await fetch("https://www.googleapis.com/gmail/v1/users/me/drafts", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ message: { raw } })
  });
  if (!response.ok) {
    const payload = await response.text();
    throw new Error(`Gmail draft creation failed: ${response.status} ${payload}`);
  }
  return response.json();
}

function getHistory() {
  return new Promise((resolve) => chrome.storage.local.get(["applicationHistory"], (data) => resolve(data.applicationHistory || [])));
}

function setHistory(history) {
  return new Promise((resolve) => chrome.storage.local.set({ applicationHistory: history }, resolve));
}

function renderEntries(entries) {
  const body = document.getElementById("historyBody");
  body.innerHTML = "";
  entries.forEach((entry) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${new Date(entry.date).toLocaleString()}</td>
      <td><a href="${entry.postUrl}" target="_blank" rel="noopener">Link</a></td>
      <td>${entry.role || "N/A"}</td>
      <td>${entry.method || "N/A"}</td>
      <td>${entry.mode === "easy_apply_only" ? "Easy Apply Only" : entry.mode || "Feed"}</td>
      <td>${entry.status || "N/A"}</td>
    `;
    body.appendChild(row);
  });
}

function filterEntries(entries) {
  const role = document.getElementById("roleFilter").value;
  const method = document.getElementById("methodFilter").value;
  const mode = document.getElementById("modeFilter").value;
  const fromDate = document.getElementById("fromDate").value;
  const toDate = document.getElementById("toDate").value;
  return entries.filter((entry) => {
    if (role !== "all" && entry.role !== role) return false;
    if (method !== "all" && entry.method !== method) return false;
    if (mode !== "all" && entry.mode !== mode) return false;
    if (fromDate && new Date(entry.date) < new Date(fromDate)) return false;
    if (toDate && new Date(entry.date) > new Date(toDate + "T23:59:59")) return false;
    return true;
  });
}

function populateRoleFilter(entries) {
  const select = document.getElementById("roleFilter");
  const roles = Array.from(new Set(entries.map((item) => item.role).filter(Boolean)));
  select.innerHTML = `<option value="all">All roles</option>${roles.map((role) => `<option value="${role}">${role}</option>`).join("")}`;
}

function buildCsv(entries) {
  const header = ["Date", "Post URL", "Role", "Method", "Mode", "Status"];
  const rows = entries.map((entry) => [
    new Date(entry.date).toISOString(),
    entry.postUrl,
    entry.role,
    entry.method,
    entry.mode === "easy_apply_only" ? "Easy Apply Only" : entry.mode || "Feed",
    entry.status
  ]);
  const csvRows = [header, ...rows].map((row) => row.map((value) => `"${String(value || "").replace(/"/g, '""')}"`).join(","));
  return csvRows.join("\r\n");
}

async function refresh() {
  const history = await getHistory();
  populateRoleFilter(history);
  renderEntries(filterEntries(history));
}

document.getElementById("roleFilter").addEventListener("change", refresh);
document.getElementById("methodFilter").addEventListener("change", refresh);
document.getElementById("modeFilter").addEventListener("change", refresh);
document.getElementById("fromDate").addEventListener("change", refresh);
document.getElementById("toDate").addEventListener("change", refresh);

document.getElementById("exportCsv").addEventListener("click", async () => {
  const history = await getHistory();
  const csv = buildCsv(history);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "linkedin-job-bot-history.csv";
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById("clearHistory").addEventListener("click", async () => {
  await setHistory([]);
  refresh();
});

refresh();

function getSettings() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (response) => {
      resolve(response.settings || {});
    });
  });
}

function updateUi(settings) {
  const stats = settings.stats || {};
  document.getElementById("applied-count").innerText = stats.totalApplied || 0;
  document.getElementById("emailed-count").innerText = stats.totalEmailed || 0;
  document.getElementById("auto-apply-toggle").checked = !!settings.preferences?.autoApply;
  document.getElementById("email-fallback-toggle").checked = !!settings.preferences?.emailFallback;
}

function savePreference(key, value) {
  chrome.storage.sync.get(["preferences"], (data) => {
    const preferences = data.preferences || {};
    preferences[key] = value;
    chrome.storage.sync.set({ preferences });
  });
}

function init() {
  getSettings().then(updateUi);

  document.getElementById("scan-now").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "SCAN_PAGE" });
    document.getElementById("status-text").innerText = "Scanning page...";
  });

  document.getElementById("open-settings").addEventListener("click", (event) => {
    event.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  document.getElementById("open-history").addEventListener("click", (event) => {
    event.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL("history.html") });
  });

  document.getElementById("auto-apply-toggle").addEventListener("change", (event) => {
    savePreference("autoApply", event.target.checked);
  });

  document.getElementById("email-fallback-toggle").addEventListener("change", (event) => {
    savePreference("emailFallback", event.target.checked);
  });
}

document.addEventListener("DOMContentLoaded", init);
